"""
FRONTIER PREMIUM - Sidebar Navigation
Collapsible (220px <-> 70px) sidebar with animated width transition and
active-item highlighting.
"""
from PySide6.QtCore import Qt, Signal, QPropertyAnimation, QEasingCurve
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy

from core.theme import Colors

NAV_ITEMS = [
    ("home", "🏠", "Home"),
    ("general", "⚙", "General"),
    ("hardware", "🖥", "Hardware"),
    ("debloat", "🗑", "Debloat"),
    ("network", "🌐", "Network"),
    ("advanced", "🔥", "Advanced"),
    ("game_mode", "🎮", "Frontier Game Mode"),
    ("backups", "🛠", "Backups & Fixes"),
    ("support", "💬", "Support"),
]

EXPANDED_WIDTH = 220
COLLAPSED_WIDTH = 70


class Sidebar(QWidget):
    page_selected = Signal(str)
    collapse_toggled = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self._collapsed = False
        self._nav_buttons: dict[str, QPushButton] = {}
        self._active_id = "home"

        self.setFixedWidth(EXPANDED_WIDTH)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 20, 0, 16)
        root.setSpacing(4)

        # --- Branding block ---------------------------------------------------
        brand_row = QHBoxLayout()
        brand_row.setContentsMargins(18, 0, 12, 20)
        self.brand_label = QLabel(f"<span style='color:{Colors.ACCENT};font-size:20px;'>⚡</span> "
                                   f"<b>FRONTIER</b><br/><span style='color:{Colors.TEXT_SECONDARY};"
                                   f"font-size:10px;letter-spacing:2px;'>PREMIUM &nbsp;v1.0</span>")
        self.brand_label.setTextFormat(Qt.RichText)
        brand_row.addWidget(self.brand_label)
        collapse_btn = QPushButton("«")
        collapse_btn.setFixedSize(26, 26)
        collapse_btn.setProperty("ghost", "true")
        collapse_btn.setCursor(Qt.PointingHandCursor)
        collapse_btn.clicked.connect(self.toggle_collapsed)
        self._collapse_btn = collapse_btn
        brand_row.addWidget(collapse_btn)
        root.addLayout(brand_row)

        # --- Nav items ----------------------------------------------------------
        for item_id, icon, label in NAV_ITEMS:
            btn = QPushButton(f"{icon}   {label}")
            btn.setProperty("navItem", "true")
            btn.setProperty("active", item_id == self._active_id)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(42)
            btn.clicked.connect(lambda checked=False, i=item_id: self._select(i))
            root.addWidget(btn)
            self._nav_buttons[item_id] = btn
            if item_id == "backups":  # visual separator before utility items
                root.addSpacing(10)

        root.addStretch()

        # --- Footer / score mini badge -----------------------------------------
        self.footer = QLabel("FRONTIER SCORE\n—")
        self.footer.setStyleSheet(f"color:{Colors.TEXT_SECONDARY}; font-size: 10px; padding: 0 18px;")
        root.addWidget(self.footer)

        self._anim = QPropertyAnimation(self, b"minimumWidth", self)
        self._anim.setDuration(220)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim2 = QPropertyAnimation(self, b"maximumWidth", self)
        self._anim2.setDuration(220)
        self._anim2.setEasingCurve(QEasingCurve.OutCubic)

    def _select(self, item_id: str):
        self._active_id = item_id
        for iid, btn in self._nav_buttons.items():
            btn.setProperty("active", iid == item_id)
            btn.style().unpolish(btn)
            btn.style().polish(btn)
            if self._collapsed:
                btn.setText(dict((i, ic) for i, ic, _ in NAV_ITEMS)[iid])
        self.page_selected.emit(item_id)

    def toggle_collapsed(self):
        self._collapsed = not self._collapsed
        target = COLLAPSED_WIDTH if self._collapsed else EXPANDED_WIDTH
        for anim in (self._anim, self._anim2):
            anim.stop()
            anim.setStartValue(self.width())
            anim.setEndValue(target)
            anim.start()

        self.brand_label.setVisible(not self._collapsed)
        self._collapse_btn.setText("»" if self._collapsed else "«")
        for item_id, icon, label in NAV_ITEMS:
            btn = self._nav_buttons[item_id]
            btn.setText(icon if self._collapsed else f"{icon}   {label}")
        self.footer.setVisible(not self._collapsed)
        self.collapse_toggled.emit(self._collapsed)

    def update_score(self, gaming: int, latency: int, optimization: int):
        self.footer.setText(f"FRONTIER SCORE\nGaming {gaming}%  ·  Latency {latency}%  ·  Opt {optimization}%")
