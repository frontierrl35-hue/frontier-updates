"""
FRONTIER PREMIUM - Base Page
Common scrollable container used by every sidebar page, plus a shared
FlowGrid helper for laying out tweak/stat cards responsively.

NOTE: this used to fade each page in via a QGraphicsOpacityEffect that
snapped opacity to 0.0 on every single sidebar click and relied on a
QPropertyAnimation timer to bring it back to 1.0. That's a well-known
class of Qt bug: if the animation doesn't fire for any reason (blocked
event loop, animations disabled, timing edge case), the page is left
permanently invisible after switching to it - which is exactly the
"click sidebar, nothing shows up" symptom this app was hitting. The
fade was purely cosmetic, so it's been removed rather than made more
defensive - one less thing that can silently break page switching.
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QGridLayout, QLabel


class BasePage(QWidget):
    """Subclasses build their content into `self.content_layout`."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(700, 500)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.scroll = QScrollArea()
        self.scroll.setMinimumSize(650, 450)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self._container = QWidget()
        self._container.setMinimumSize(600, 400)
        self._container.setObjectName("PageContainer")
        self.content_layout = QVBoxLayout(self._container)
        self.content_layout.setContentsMargins(32, 28, 32, 28)
        self.content_layout.setSpacing(18)
        self._page_status = QLabel("Frontier Premium module loaded")
        self._page_status.setObjectName("PageStatusDebug")
        self.content_layout.addWidget(self._page_status)

        self.scroll.setWidget(self._container)
        outer.addWidget(self.scroll)

    def on_shown(self):
        """Override in subclasses that need to refresh live data each time
        the page becomes visible. Base implementation just makes sure the
        page is actually drawn immediately instead of waiting on the next
        natural repaint, which otherwise can leave a freshly-switched-to
        page looking blank for a moment on some systems."""
        self.show()
        self.update()
        self.repaint()


def make_grid() -> QGridLayout:
    grid = QGridLayout()
    grid.setSpacing(14)
    return grid
