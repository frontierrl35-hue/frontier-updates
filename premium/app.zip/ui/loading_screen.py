"""
FRONTIER PREMIUM - Startup Loading Screen
Full-window overlay shown while the engine "initializes": animated glow
logo, staged checklist, and a progress bar. Purely cosmetic timing driven by
a QTimer so it works identically with or without real hardware sensors.
"""
from PySide6.QtCore import Qt, QTimer, Signal, QPropertyAnimation, QEasingCurve, Property
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar, QGraphicsOpacityEffect
from PySide6.QtGui import QFont

from core.theme import Colors

STAGES = [
    "Hardware Detection",
    "Loading Modules",
    "Checking System",
    "Preparing Dashboard",
]


class LoadingScreen(QWidget):
    finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAutoFillBackground(True)
        self.setStyleSheet(f"background-color: {Colors.BACKGROUND};")

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(18)

        self.logo = QLabel("⚡")
        self.logo.setAlignment(Qt.AlignCenter)
        logo_font = QFont()
        logo_font.setPointSize(54)
        self.logo.setFont(logo_font)
        self.logo.setStyleSheet(f"color: {Colors.ACCENT};")
        layout.addWidget(self.logo)

        self._glow_effect = QGraphicsOpacityEffect(self.logo)
        self.logo.setGraphicsEffect(self._glow_effect)
        self._glow_anim = QPropertyAnimation(self._glow_effect, b"opacity", self)
        self._glow_anim.setDuration(1100)
        self._glow_anim.setStartValue(0.5)
        self._glow_anim.setEndValue(1.0)
        self._glow_anim.setEasingCurve(QEasingCurve.InOutSine)
        self._glow_anim.setLoopCount(-1)
        self._glow_dir = 1

        title = QLabel("FRONTIER PREMIUM")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 22px; font-weight: 800; letter-spacing: 4px;")
        layout.addWidget(title)

        subtitle = QLabel("Initializing Optimization Engine")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet(f"color: {Colors.TEXT_SECONDARY}; font-size: 12px;")
        layout.addWidget(subtitle)

        layout.addSpacing(10)

        self.stage_labels: list[QLabel] = []
        for stage in STAGES:
            lbl = QLabel(f"○  {stage}")
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setStyleSheet(f"color: {Colors.TEXT_SECONDARY}; font-size: 12px;")
            layout.addWidget(lbl)
            self.stage_labels.append(lbl)

        layout.addSpacing(14)

        self.progress = QProgressBar()
        self.progress.setFixedWidth(320)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        layout.addWidget(self.progress, alignment=Qt.AlignCenter)

        self.percent_label = QLabel("0%")
        self.percent_label.setAlignment(Qt.AlignCenter)
        self.percent_label.setStyleSheet(f"color: {Colors.ACCENT}; font-weight: 700;")
        layout.addWidget(self.percent_label)

        self._progress_val = 0
        self._stage_idx = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

    def start(self):
        self._glow_anim.start()
        self._timer.start(35)

    def _tick(self):
        self._progress_val += 2
        self.progress.setValue(min(self._progress_val, 100))
        self.percent_label.setText(f"{min(self._progress_val, 100)}%")

        stage_target = min(len(STAGES) - 1, self._progress_val // (100 // len(STAGES)))
        if stage_target > self._stage_idx:
            self._complete_stage(self._stage_idx)
            self._stage_idx = stage_target

        if self._progress_val >= 100:
            self._complete_stage(self._stage_idx)
            self._timer.stop()
            self._glow_anim.stop()
            QTimer.singleShot(260, self.finished.emit)

    def _complete_stage(self, idx: int):
        if 0 <= idx < len(self.stage_labels):
            self.stage_labels[idx].setText(f"✓  {STAGES[idx]}")
            self.stage_labels[idx].setStyleSheet(f"color: {Colors.SUCCESS}; font-size: 12px; font-weight: 600;")
