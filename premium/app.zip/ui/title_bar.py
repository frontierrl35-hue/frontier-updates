"""
FRONTIER PREMIUM - Custom Title Bar
Frameless-window title bar: branding, drag-to-move, minimize / maximize / close.
"""
from PySide6.QtCore import Qt, QPoint
from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel, QPushButton, QSizePolicy

from core.theme import Colors


class TitleBar(QWidget):
    def __init__(self, window: QWidget, parent=None):
        super().__init__(parent)
        self.setObjectName("TitleBar")
        self._window = window
        self._drag_pos: QPoint | None = None
        self.setFixedHeight(44)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 8, 0)
        layout.setSpacing(8)

        logo = QLabel("⚡")
        logo.setStyleSheet(f"color: {Colors.ACCENT}; font-size: 18px; font-weight: 900;")
        layout.addWidget(logo)

        title = QLabel("FRONTIER  <span style='color:%s;'>PREMIUM</span>" % Colors.ACCENT)
        title.setStyleSheet("font-size: 13px; font-weight: 700; letter-spacing: 1px;")
        layout.addWidget(title)

        version = QLabel("v1.0")
        version.setStyleSheet(f"color: {Colors.TEXT_SECONDARY}; font-size: 11px;")
        layout.addWidget(version)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        layout.addWidget(spacer)

        self.min_btn = QPushButton("─")
        self.max_btn = QPushButton("□")
        self.close_btn = QPushButton("✕")
        for btn in (self.min_btn, self.max_btn, self.close_btn):
            btn.setProperty("titleBtn", "true")
            btn.setFixedSize(34, 30)
            btn.setCursor(Qt.PointingHandCursor)
        self.close_btn.setProperty("closeBtn", "true")

        self.min_btn.clicked.connect(self._window.showMinimized)
        self.max_btn.clicked.connect(self._toggle_max)
        self.close_btn.clicked.connect(self._window.close)

        layout.addWidget(self.min_btn)
        layout.addWidget(self.max_btn)
        layout.addWidget(self.close_btn)

    def _toggle_max(self):
        if self._window.isMaximized():
            self._window.showNormal()
        else:
            self._window.showMaximized()

    # --- drag-to-move support -------------------------------------------------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self._window.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() & Qt.LeftButton:
            self._window.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseDoubleClickEvent(self, event):
        self._toggle_max()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
