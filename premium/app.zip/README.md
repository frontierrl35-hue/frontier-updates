# ⚡ FRONTIER PREMIUM 1.0

Professional Windows Optimization Suite / Gaming Performance Utility — built with
Python 3.12+ and PySide6, in a red/black premium gaming aesthetic.

## Features

- Frameless custom-titled window with drag, rounded corners, and a startup
  loading sequence
- Collapsible sidebar (220px ↔ 70px) with 9 sections: Home, General,
  Hardware, Debloat, Network, Advanced, Frontier Game Mode, Backups & Fixes,
  Support
- Live Task-Manager-style dashboard: CPU / GPU / RAM / Storage readouts,
  rolling performance graphs, and a composite **Frontier Score**
- One-click **⚡ OPTIMIZE PC** that runs the full tweak engine on a
  background thread with a staged progress overlay
- Modular, data-driven **tweak engine** (`core/tweak_engine.py`) covering
  General, CPU, GPU, RAM, Input, Storage, Network and Advanced tweaks — each
  tweak knows how to `apply()` *and* `revert()` itself, and every action is
  written to a SQLite log
- **Debloat Center** for built-in Microsoft Store apps (remove / restore,
  individually or in bulk)
- **Network Priority Tool** (per-executable QoS policy) and a **Bufferbloat
  Test** (idle vs. loaded latency)
- **Frontier Game Mode**: detects supported games and boosts their process
  priority while trimming background apps
- **Backups & Fixes**: one-click System Restore point + repair tools for
  Audio, Bluetooth, Network, NVIDIA, Microsoft Store, Discord, Adobe and AMD
  services
- **Support page**: Discord card, update checker, theme settings (red
  intensity / animations / compact mode), activity log viewer and
  `Frontier_Report.html` export

## Getting started (Windows — one-click)

1. Unzip the project anywhere.
2. Double-click **`INSTALL.bat`** — checks for Python, creates a private
   `.venv` virtual environment, and installs every dependency
   (PySide6, psutil, GPUtil, pywin32, wmi, matplotlib, requests, pillow,
   py-cpuinfo). Needs an internet connection; takes a few minutes the first
   time.
3. Double-click **`RUN_FRONTIER.bat`** — prompts for Administrator rights
   (needed for registry/service/powercfg tweaks to actually apply), then
   opens the full GUI. Use the app normally from here, including the
   ⚡ **OPTIMIZE PC** button.

   Prefer to skip the UI entirely? **`QUICK_OPTIMIZE.bat`** self-elevates,
   creates a restore point, and applies every tweak straight from the
   console — the same engine and logging the GUI button uses.

## Getting started (manual / macOS / Linux)

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows
source .venv/bin/activate       # macOS / Linux
pip install -r requirements.txt
python main.py
```

> The tweak engine only executes real registry/PowerShell/powercfg commands
> when running on Windows (`os.name == "nt"`). On macOS/Linux it runs in a
> fully-functional **simulation mode** so the UI is demoable everywhere —
> every apply/revert call still logs to SQLite and updates the config, it
> just doesn't touch the (nonexistent) Windows registry.
>
> Some tweaks modify system-level Windows Registry and power settings.
> **Run as Administrator** on Windows for tweaks to apply successfully, and
> use the **Backups & Fixes → Create Restore Point** button before your
> first Optimize pass.

## Project layout

```
frontier_premium/
├── INSTALL.bat               # sets up venv + installs all dependencies
├── RUN_FRONTIER.bat           # self-elevates, launches the GUI
├── QUICK_OPTIMIZE.bat          # self-elevates, applies every tweak headlessly
├── main.py                  # entry point: loading screen -> main window
├── core/
│   ├── cli_optimize.py        # headless "apply all tweaks" console script
│   ├── theme.py              # color palette, fonts, QSS stylesheet
│   ├── config.py              # JSON config persistence
│   ├── database.py            # SQLite activity + tweak-history log
│   ├── tweak_engine.py        # data-driven tweak definitions (apply/revert)
│   ├── system_info.py         # psutil/GPUtil/py-cpuinfo hardware monitor
│   ├── debloat_engine.py      # Appx package removal/restore
│   ├── network_tools.py       # QoS priority + bufferbloat test
│   ├── game_mode.py           # game process detection + priority boost
│   ├── backup_engine.py       # restore points + repair tools
│   └── report.py              # HTML report export + update checker
└── ui/
    ├── main_window.py         # frameless window, sidebar + page routing
    ├── title_bar.py           # custom draggable title bar
    ├── sidebar.py              # collapsible nav sidebar
    ├── loading_screen.py       # startup animation
    ├── widgets.py               # ToggleSwitch, StatCard, TweakCard, LiveGraph, Toast
    └── pages/                   # one module per sidebar section
```

## Extending the tweak catalog

Every tweak is a `core.tweak_engine.Tweak` — add a new one anywhere in
`core/tweak_engine.py` with an `id`, `label`, `description`, `category`, and
`apply_fn` / `revert_fn` callables, and it will automatically appear on the
matching page (`TweakCategoryPage` / `TweakSection` render every tweak in a
`TweakCategory` with zero extra UI code).

## Support

Join the Discord: https://discord.gg/sG9jVNJsj
