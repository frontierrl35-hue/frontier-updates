"""
FRONTIER PREMIUM 1.0
Professional Windows Optimization Suite

Entry point: builds the QApplication, applies the global theme, shows the
startup loading screen, then swaps in the main window.
"""
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout

from core.theme import build_stylesheet
from ui.loading_screen import LoadingScreen
from ui.main_window import MainWindow


def _load_fonts():
    """Loads bundled Inter / JetBrains Mono fonts if present under
    assets/fonts/. Falls back silently to system fonts (Segoe UI / Consolas)
    when the .ttf files aren't bundled — see assets/fonts/README.txt."""
    import os
    font_dir = os.path.join(os.path.dirname(__file__), "assets", "fonts")
    if os.path.isdir(font_dir):
        for fname in os.listdir(font_dir):
            if fname.lower().endswith((".ttf", ".otf")):
                QFontDatabase.addApplicationFont(os.path.join(font_dir, fname))


class BootWindow(QWidget):
    """A borderless container that first shows the LoadingScreen, then
    hands off to the real frameless MainWindow."""

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.resize(1300, 800)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.loading = LoadingScreen()
        self.loading.finished.connect(self._on_loading_finished)
        layout.addWidget(self.loading)

        self.main_window = None

    def start(self):
        self.show()
        self.loading.start()

    def _on_loading_finished(self):
        self.main_window = MainWindow()
        self.main_window.resize(self.size())
        self.main_window.move(self.pos())
        self.main_window.show()
        self.close()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Frontier Premium")
    app.setStyleSheet(build_stylesheet())

    default_font = QFont("Segoe UI", 10)
    app.setFont(default_font)
    _load_fonts()

    boot = BootWindow()
    boot.start()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
