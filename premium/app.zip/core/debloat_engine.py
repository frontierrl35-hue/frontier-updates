"""
FRONTIER PREMIUM - Debloat Center
Removes/restores built-in Microsoft Store (UWP) apps via PowerShell's
Get-AppxPackage / Remove-AppxPackage cmdlets. Restore uses
Add-AppxPackage -Register against the manifest, which works for the
current user without needing the original install source in most cases.
"""
from __future__ import annotations

from dataclasses import dataclass

from core import database
from core.config import config
from core.tweak_engine import _run_powershell  # reuse safe shell runner

BLOAT_APPS = [
    ("copilot", "Copilot", "Microsoft.Windows.Copilot"),
    ("cortana", "Cortana", "Microsoft.549981C3F5F10"),
    ("xbox", "Xbox App", "Microsoft.GamingApp"),
    ("clipchamp", "Clipchamp", "Clipchamp.Clipchamp"),
    ("feedback_hub", "Feedback Hub", "Microsoft.WindowsFeedbackHub"),
    ("3d_viewer", "3D Viewer", "Microsoft.Microsoft3DViewer"),
    ("maps", "Maps", "Microsoft.WindowsMaps"),
    ("mail_calendar", "Mail and Calendar", "microsoft.windowscommunicationsapps"),
    ("mixed_reality", "Mixed Reality Portal", "Microsoft.MixedReality.Portal"),
    ("dev_home", "Dev Home", "Microsoft.Windows.DevHome"),
    ("family_safety", "Family Safety", "MicrosoftCorporationII.MicrosoftFamily"),
    ("get_help", "Get Help", "Microsoft.GetHelp"),
    ("camera", "Camera", "Microsoft.WindowsCamera"),
    ("alarms", "Alarms and Clock", "Microsoft.WindowsAlarms"),
]


@dataclass
class BloatApp:
    id: str
    label: str
    package_family: str

    def is_removed(self) -> bool:
        return bool(config.get("debloat", self.id, default=False))

    def remove(self) -> tuple[bool, str]:
        ok, out = _run_powershell(
            f"Get-AppxPackage *{self.package_family}* | Remove-AppxPackage -ErrorAction SilentlyContinue; "
            f"Get-AppxProvisionedPackage -Online | Where-Object DisplayName -like '*{self.package_family}*' "
            f"| Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue"
        )
        config.set("debloat", self.id, True)
        database.log("Debloat", f"Removed {self.label}", "success" if ok else "error")
        return ok, out

    def restore(self) -> tuple[bool, str]:
        ok, out = _run_powershell(
            f"Get-AppxPackage -AllUsers *{self.package_family}* | "
            f"Foreach-Object {{Add-AppxPackage -DisableDevelopmentMode -Register "
            f"\"$($_.InstallLocation)\\AppXManifest.xml\"}}"
        )
        config.set("debloat", self.id, False)
        database.log("Debloat", f"Restored {self.label}", "success" if ok else "error")
        return ok, out


APPS = [BloatApp(*a) for a in BLOAT_APPS]
APPS_BY_ID = {a.id: a for a in APPS}


def remove_selected(ids: list[str], progress_cb=None):
    results = []
    for i, app_id in enumerate(ids, start=1):
        app = APPS_BY_ID.get(app_id)
        if not app:
            continue
        ok, out = app.remove()
        results.append((app, ok, out))
        if progress_cb:
            progress_cb(app.label, i, len(ids))
    return results


def remove_all():
    return remove_selected([a.id for a in APPS])


def restore_all():
    results = []
    for app in APPS:
        if app.is_removed():
            results.append((app, *app.restore()))
    return results
