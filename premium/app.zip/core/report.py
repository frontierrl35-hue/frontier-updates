"""
FRONTIER PREMIUM - Report Export & Update Checker
Generates Frontier_Report.html summarizing hardware, applied tweaks,
performance score and recent errors. Also a stub update checker that
compares the local version against a remote manifest (replace URL with a
real endpoint you control before shipping).
"""
from __future__ import annotations

import datetime
from pathlib import Path

import requests

from core import database
from core.config import config
from core.tweak_engine import ALL_TWEAKS
from core import system_info

APP_VERSION = "1.01"
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/frontierrl35-hue/frontier-updates/main/premium/version.json"


def generate_html_report(output_path: str | Path = "Frontier_Report.html") -> Path:
    cpu = system_info.get_cpu_info()
    ram = system_info.get_ram_info()
    gpus = system_info.get_gpu_info()
    storage = system_info.get_storage_info()

    applied = [t for t in ALL_TWEAKS if t.is_enabled()]
    score = system_info.compute_frontier_score(cpu, ram, len(applied), len(ALL_TWEAKS))
    logs = database.recent_logs(limit=50)
    errors = [l for l in logs if l["level"] == "error"]

    rows_tweaks = "".join(
        f"<tr><td>{t.category.value}</td><td>{t.label}</td><td style='color:#00FF88'>Applied</td></tr>"
        for t in applied
    ) or "<tr><td colspan='3'>No tweaks applied yet.</td></tr>"

    rows_errors = "".join(
        f"<tr><td>{datetime.datetime.fromtimestamp(e['ts']):%Y-%m-%d %H:%M}</td>"
        f"<td>{e['category']}</td><td>{e['message']}</td></tr>"
        for e in errors
    ) or "<tr><td colspan='3'>No errors logged.</td></tr>"

    gpu_html = "".join(
        f"<p>{g.name} — {g.usage_percent}% load, {g.vram_used_mb}/{g.vram_total_mb} MB VRAM, "
        f"{g.temperature_c if g.temperature_c is not None else 'N/A'}°C</p>" for g in gpus
    )

    storage_html = "".join(
        f"<p>{d['letter']} — {d['used_gb']} / {d['total_gb']} GB ({d['percent']}%)</p>"
        for d in storage.drives
    )

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Frontier Premium Report</title>
<style>
body {{ background:#070707; color:#fff; font-family: Segoe UI, sans-serif; padding:40px; }}
h1 {{ color:#E00000; }}
h2 {{ border-bottom:1px solid #242424; padding-bottom:6px; }}
table {{ width:100%; border-collapse:collapse; margin-bottom:24px; }}
td, th {{ padding:8px; border-bottom:1px solid #191919; text-align:left; }}
.score {{ display:inline-block; margin-right:40px; }}
.score .num {{ font-size:32px; font-weight:bold; color:#E00000; }}
</style></head><body>
<h1>⚡ FRONTIER PREMIUM — System Report</h1>
<p>Generated {datetime.datetime.now():%Y-%m-%d %H:%M} — Version {APP_VERSION}</p>

<h2>Frontier Score</h2>
<div class="score"><div class="num">{score['gaming']}%</div>Gaming</div>
<div class="score"><div class="num">{score['latency']}%</div>Latency</div>
<div class="score"><div class="num">{score['optimization']}%</div>Optimization</div>

<h2>Hardware</h2>
<p><b>CPU:</b> {cpu.name} — {cpu.core_count}C/{cpu.thread_count}T @ {cpu.clock_mhz:.0f} MHz, {cpu.usage_percent}% load</p>
{gpu_html}
<p><b>RAM:</b> {ram.used_gb} / {ram.total_gb} GB ({ram.percent}%)</p>
{storage_html}

<h2>Applied Tweaks ({len(applied)} / {len(ALL_TWEAKS)})</h2>
<table><tr><th>Category</th><th>Tweak</th><th>Status</th></tr>{rows_tweaks}</table>

<h2>Recent Errors</h2>
<table><tr><th>Time</th><th>Category</th><th>Message</th></tr>{rows_errors}</table>

</body></html>"""

    out = Path(output_path)
    out.write_text(html, encoding="utf-8")
    database.log("System", f"Exported report to {out}")
    return out


def check_for_update() -> dict:
    """Returns {'update_available', 'latest_version', 'changelog',
    'download_url', 'error'}. 'error' is None on a successful check, or a
    short human-readable reason the check itself failed (network issue,
    bad manifest, etc.) — callers should show this distinctly from 'no
    update available' rather than treating every failure as 'up to date'."""
    try:
        resp = requests.get(UPDATE_MANIFEST_URL, timeout=8)
        resp.raise_for_status()
        manifest = resp.json()
        latest = manifest.get("version", APP_VERSION)
        return {
            "update_available": latest != APP_VERSION,
            "latest_version": latest,
            "changelog": manifest.get("changelog", ""),
            "download_url": manifest.get("download_url", ""),
            "error": None,
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "update_available": False,
            "latest_version": APP_VERSION,
            "changelog": "",
            "download_url": "",
            "error": str(exc),
        }
