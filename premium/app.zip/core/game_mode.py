"""
FRONTIER PREMIUM - Frontier Game Mode
Watches for known game processes and, when enabled, raises their priority
and trims background load while they're running.
"""
from __future__ import annotations

import psutil

from core import database
from core.config import config

KNOWN_GAMES = {
    "FortniteClient-Win64-Shipping.exe": "Fortnite",
    "RocketLeague.exe": "Rocket League",
    "VALORANT-Win64-Shipping.exe": "VALORANT",
    "cs2.exe": "Counter-Strike 2",
    "GTA5.exe": "GTA V",
    "Minecraft.exe": "Minecraft",
    "javaw.exe": "Minecraft (Java)",
}

BACKGROUND_TRIM_TARGETS = [
    "OneDrive.exe", "Widgets.exe", "YourPhone.exe", "Teams.exe",
]


def scan_for_running_games() -> list[tuple[str, str, int]]:
    """Returns [(exe_name, friendly_name, pid), ...] for any watched game
    currently running."""
    watched = set(config.get("game_mode", "watched_games", default=list(KNOWN_GAMES)))
    found = []
    for proc in psutil.process_iter(["pid", "name"]):
        name = proc.info.get("name") or ""
        if name in watched:
            found.append((name, KNOWN_GAMES.get(name, name), proc.info["pid"]))
    return found


def boost_process(pid: int) -> tuple[bool, str]:
    try:
        p = psutil.Process(pid)
        if hasattr(psutil, "HIGH_PRIORITY_CLASS"):
            p.nice(psutil.HIGH_PRIORITY_CLASS)
        else:
            p.nice(-10)
        database.log("Game Mode", f"Boosted priority for PID {pid} ({p.name()})", "success")
        return True, f"Boosted {p.name()} (PID {pid}) to High priority."
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def trim_background_apps() -> list[str]:
    trimmed = []
    for proc in psutil.process_iter(["pid", "name"]):
        name = proc.info.get("name") or ""
        if name in BACKGROUND_TRIM_TARGETS:
            try:
                p = psutil.Process(proc.info["pid"])
                if hasattr(psutil, "BELOW_NORMAL_PRIORITY_CLASS"):
                    p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
                else:
                    p.nice(5)
                trimmed.append(name)
            except Exception:  # noqa: BLE001
                continue
    if trimmed:
        database.log("Game Mode", f"Lowered priority for background apps: {', '.join(trimmed)}")
    return trimmed


def set_enabled(enabled: bool):
    config.set("game_mode", "enabled", enabled)
    database.log("Game Mode", f"Frontier Game Mode {'enabled' if enabled else 'disabled'}")
