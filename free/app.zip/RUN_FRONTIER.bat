@echo off
setlocal
title Frontier Premium 1.0
cd /d "%~dp0"

net session >nul 2>&1
if not %errorlevel%==0 (
 powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
 exit /b
)

if not exist ".venv\Scripts\python.exe" (
 echo Frontier is not installed.
 echo Run INSTALL.bat first.
 pause
 exit /b 1
)

echo Launching Frontier Premium...
".venv\Scripts\python.exe" "%~dp0main.py"

if errorlevel 1 (
 echo.
 echo Frontier closed with an error.
 pause
)
