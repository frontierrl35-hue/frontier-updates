# ⚡ FRONTIER FREE 1.0

A compact, free introduction to Frontier Tweaks — built with Python 3.12+
and PySide6, in a blue/black aesthetic.

Frontier Free gives you a taste of the optimization suite: a live system
dashboard, one-click optimize, and a handful of tweaks per category. Upgrade
to **Frontier Premium** for the full tweak catalog, Advanced tweaks, the
complete Debloat Center, expanded Game Mode detection, and more.

## Features (Free)

- Frameless custom-titled window with the live system dashboard
- Collapsible sidebar with 8 sections: Home, General, Hardware, Debloat,
  Network, Frontier Game Mode, Backups & Fixes, Support
- Live CPU / GPU / RAM / Storage readouts and your **Frontier Score**
- One-click **⚡ OPTIMIZE PC** — applies the Free tweak set
- A compact tweak set (2 tweaks per category) covering General, CPU, GPU,
  RAM, Input, Storage and Network
- Compact **Debloat Center** (5 common apps) and **Frontier Game Mode**
  (top 3 titles)
- **Backups & Fixes**: one-click System Restore point + repair tools
- **Support page**: Discord card, update checker, theme settings, activity
  log viewer and report export

## Getting started (Windows — one-click)

1. Unzip the project anywhere.
2. Double-click **`INSTALL.bat`** — checks for Python, creates a private
   `.venv` virtual environment, and installs every dependency. Needs an
   internet connection; takes a few minutes the first time.
3. Double-click **`RUN_FRONTIER.bat`** — prompts for Administrator rights
   (needed for registry/service/powercfg tweaks to actually apply), then
   opens the full GUI.

   Prefer to skip the UI entirely? **`QUICK_OPTIMIZE.bat`** self-elevates,
   creates a restore point, and applies the Free tweak set straight from
   the console.

## Getting started (manual / macOS / Linux)

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows
source .venv/bin/activate       # macOS / Linux
pip install -r requirements.txt
python main.py
```

> The tweak engine only executes real registry/PowerShell/powercfg commands
> when running on Windows (`os.name == "nt"`). On macOS/Linux it runs in a
> fully-functional **simulation mode**.

## Support

Join the Discord: https://discord.gg/sG9jVNJsj

Want the full suite? Ask about **Frontier Premium**.
