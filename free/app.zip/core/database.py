"""
FRONTIER PREMIUM - Logging Database
SQLite-backed activity log used by the Logs panel and HTML report export.
"""
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

from core.config import get_app_data_dir

DB_PATH = get_app_data_dir() / "frontier.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    level TEXT NOT NULL,          -- info | success | warning | error
    category TEXT NOT NULL,       -- e.g. GPU, Debloat, Network, System
    message TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tweak_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    tweak_id TEXT NOT NULL,
    tweak_label TEXT NOT NULL,
    action TEXT NOT NULL,         -- applied | reverted
    success INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS restore_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    label TEXT NOT NULL,
    description TEXT
);
"""


@contextmanager
def get_conn():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)


def log(category: str, message: str, level: str = "info"):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO logs (ts, level, category, message) VALUES (?, ?, ?, ?)",
            (time.time(), level, category, message),
        )


def log_tweak(tweak_id: str, tweak_label: str, action: str, success: bool):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO tweak_history (ts, tweak_id, tweak_label, action, success) "
            "VALUES (?, ?, ?, ?, ?)",
            (time.time(), tweak_id, tweak_label, action, int(success)),
        )


def log_restore_point(label: str, description: str = ""):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO restore_points (ts, label, description) VALUES (?, ?, ?)",
            (time.time(), label, description),
        )


def recent_logs(limit: int = 100):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM logs ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def all_tweak_history():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM tweak_history ORDER BY ts DESC"
        ).fetchall()
        return [dict(r) for r in rows]


init_db()
