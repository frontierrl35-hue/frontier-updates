"""
FRONTIER FREE - Self Updater
Downloads the latest app package from the manifest's `download_url` and
overwrites the local install with it. Runs entirely client-side — no
external installer needed. The user's `.venv` and any cache artifacts are
never touched, and user config/logs live outside the app folder (in
%LOCALAPPDATA%) so they're untouched by an update either way.
"""
from __future__ import annotations

import io
import shutil
import tempfile
import zipfile
from pathlib import Path

import requests

APP_ROOT = Path(__file__).resolve().parents[1]

# Never overwritten by an update.
_PRESERVE = {".venv", "__pycache__", ".git"}


def download_update_zip(download_url: str, timeout: int = 30) -> bytes:
    resp = requests.get(download_url, timeout=timeout)
    resp.raise_for_status()
    return resp.content


def _copy_tree_overwrite(src: Path, dst: Path):
    """Recursively copy src into dst, overwriting existing files, while
    never touching anything in _PRESERVE."""
    for item in src.iterdir():
        if item.name in _PRESERVE:
            continue
        target = dst / item.name
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            _copy_tree_overwrite(item, target)
        else:
            shutil.copy2(item, target)


def apply_update(download_url: str, app_root: Path | None = None) -> tuple[bool, str]:
    """Downloads the zip at download_url and overwrites app_root with its
    contents. Returns (ok, message)."""
    if not download_url:
        return False, "No download URL in the update manifest."

    app_root = app_root or APP_ROOT
    try:
        data = download_update_zip(download_url)
    except Exception as exc:  # noqa: BLE001
        return False, f"Download failed: {exc}"

    try:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                zf.extractall(tmp_path)
            # The zip may contain a single top-level folder — descend into
            # it so files land directly in app_root instead of one level deep.
            entries = list(tmp_path.iterdir())
            source_root = entries[0] if len(entries) == 1 and entries[0].is_dir() else tmp_path
            _copy_tree_overwrite(source_root, app_root)
    except Exception as exc:  # noqa: BLE001
        return False, f"Update downloaded but failed to apply: {exc}"

    return True, "Update installed successfully. Restart Frontier to finish applying it."
