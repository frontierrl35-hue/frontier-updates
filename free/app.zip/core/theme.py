"""
FRONTIER FREE - Theme System
Centralized color palette, typography and QSS stylesheet generation.
Blue / Black free-edition aesthetic.
"""

class Colors:
    BACKGROUND = "#070709"
    CARD = "#111318"
    SECONDARY = "#191c22"
    BORDER = "#242832"
    ACCENT = "#0080E0"
    GLOW = "#2FA8FF"
    TEXT = "#FFFFFF"
    TEXT_SECONDARY = "#A0A5AC"
    SUCCESS = "#00FF88"
    WARNING = "#FFB800"
    DANGER = "#FF3B3B"


class Fonts:
    PRIMARY = "Inter SemiBold"
    PRIMARY_FALLBACK = "Segoe UI Semibold"
    REGULAR = "Inter"
    REGULAR_FALLBACK = "Segoe UI"
    MONO = "JetBrains Mono"
    MONO_FALLBACK = "Consolas"


# Global adjustable theme settings (bound to Settings page -> "Red intensity" / "Compact mode")
class ThemeState:
    red_intensity: float = 1.0   # 0.5 - 1.5 multiplier, scales accent glow opacity
    animations_enabled: bool = True
    compact_mode: bool = False


def build_stylesheet() -> str:
    c = Colors
    f = Fonts
    return f"""
    * {{
        font-family: "{f.REGULAR}", "{f.REGULAR_FALLBACK}";
        color: {c.TEXT};
        outline: none;
    }}

    QWidget#RootBackground {{
        background-color: {c.BACKGROUND};
    }}

    /* ---------- Cards ---------- */
    QFrame[card="true"] {{
        background-color: {c.CARD};
        border: 1px solid {c.BORDER};
        border-radius: 14px;
    }}
    QFrame[card="true"]:hover {{
        border: 1px solid {c.ACCENT};
    }}

    QFrame[cardSecondary="true"] {{
        background-color: {c.SECONDARY};
        border: 1px solid {c.BORDER};
        border-radius: 10px;
    }}

    /* ---------- Labels ---------- */
    QLabel[role="h1"] {{
        font-family: "{f.PRIMARY}", "{f.PRIMARY_FALLBACK}";
        font-size: 24px;
        font-weight: 700;
        color: {c.TEXT};
    }}
    QLabel[role="h2"] {{
        font-family: "{f.PRIMARY}", "{f.PRIMARY_FALLBACK}";
        font-size: 16px;
        font-weight: 600;
        color: {c.TEXT};
    }}
    QLabel[role="caption"] {{
        font-size: 12px;
        color: {c.TEXT_SECONDARY};
    }}
    QLabel[role="stat"] {{
        font-family: "{f.MONO}", "{f.MONO_FALLBACK}";
        font-size: 22px;
        font-weight: 700;
        color: {c.TEXT};
    }}
    QLabel[role="accent"] {{
        color: {c.ACCENT};
        font-weight: 700;
    }}
    QLabel[role="success"] {{
        color: {c.SUCCESS};
        font-weight: 700;
    }}

    /* ---------- Buttons ---------- */
    QPushButton {{
        background-color: {c.SECONDARY};
        border: 1px solid {c.BORDER};
        border-radius: 8px;
        padding: 8px 16px;
        font-weight: 600;
    }}
    QPushButton:hover {{
        background-color: #222222;
        border: 1px solid {c.ACCENT};
    }}
    QPushButton:pressed {{
        background-color: #0d0d0d;
    }}
    QPushButton[primary="true"] {{
        background-color: {c.ACCENT};
        border: 1px solid {c.GLOW};
        color: {c.TEXT};
        font-size: 14px;
        padding: 12px 22px;
        border-radius: 10px;
    }}
    QPushButton[primary="true"]:hover {{
        background-color: {c.GLOW};
    }}
    QPushButton[ghost="true"] {{
        background-color: transparent;
        border: 1px solid {c.BORDER};
    }}
    QPushButton[ghost="true"]:hover {{
        border: 1px solid {c.ACCENT};
    }}
    QPushButton[danger="true"] {{
        background-color: transparent;
        border: 1px solid {c.DANGER};
        color: {c.DANGER};
    }}
    QPushButton[danger="true"]:hover {{
        background-color: {c.DANGER};
        color: {c.TEXT};
    }}

    /* ---------- Sidebar ---------- */
    QWidget#Sidebar {{
        background-color: #0a0a0a;
        border-right: 1px solid {c.BORDER};
    }}
    QPushButton[navItem="true"] {{
        background-color: transparent;
        border: none;
        border-radius: 8px;
        text-align: left;
        padding: 10px 14px;
        font-size: 13px;
        color: {c.TEXT_SECONDARY};
        font-weight: 600;
    }}
    QPushButton[navItem="true"]:hover {{
        background-color: {c.SECONDARY};
        color: {c.TEXT};
    }}
    QPushButton[navItem="true"][active="true"] {{
        background-color: rgba(0, 128, 224, 0.18);
        color: {c.TEXT};
        border-left: 3px solid {c.ACCENT};
    }}

    /* ---------- Title bar ---------- */
    QWidget#TitleBar {{
        background-color: #050505;
        border-bottom: 1px solid {c.BORDER};
    }}
    QPushButton[titleBtn="true"] {{
        background-color: transparent;
        border: none;
        border-radius: 6px;
        padding: 4px 10px;
    }}
    QPushButton[titleBtn="true"]:hover {{
        background-color: {c.SECONDARY};
    }}
    QPushButton[closeBtn="true"]:hover {{
        background-color: {c.ACCENT};
    }}

    /* ---------- Scrollbars ---------- */
    QScrollArea {{ border: none; background: transparent; }}
    QScrollBar:vertical {{
        background: transparent;
        width: 8px;
        margin: 0;
    }}
    QScrollBar::handle:vertical {{
        background: {c.SECONDARY};
        border-radius: 4px;
        min-height: 30px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: {c.ACCENT};
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}

    /* ---------- Progress ---------- */
    QProgressBar {{
        background-color: {c.SECONDARY};
        border: none;
        border-radius: 6px;
        height: 10px;
        text-align: center;
        color: transparent;
    }}
    QProgressBar::chunk {{
        background-color: {c.ACCENT};
        border-radius: 6px;
    }}

    /* ---------- Inputs ---------- */
    QLineEdit {{
        background-color: {c.SECONDARY};
        border: 1px solid {c.BORDER};
        border-radius: 8px;
        padding: 8px 10px;
        font-family: "{f.MONO}", "{f.MONO_FALLBACK}";
    }}
    QLineEdit:focus {{
        border: 1px solid {c.ACCENT};
    }}

    QListWidget {{
        background-color: transparent;
        border: none;
    }}

    QToolTip {{
        background-color: {c.SECONDARY};
        color: {c.TEXT};
        border: 1px solid {c.ACCENT};
        padding: 4px 8px;
        border-radius: 4px;
    }}
    """
