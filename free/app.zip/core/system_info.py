"""
FRONTIER PREMIUM - Hardware Monitoring
Wraps psutil / GPUtil / py-cpuinfo / wmi behind a single, always-safe API.
Every getter degrades gracefully (returns placeholder data) if an optional
dependency or sensor isn't available on the current machine.
"""
from __future__ import annotations

import platform
import time
from dataclasses import dataclass, field

import psutil

try:
    import cpuinfo  # py-cpuinfo
except ImportError:
    cpuinfo = None

try:
    import GPUtil
except ImportError:
    GPUtil = None

IS_WINDOWS = platform.system() == "Windows"

try:
    if IS_WINDOWS:
        import wmi
        _WMI = wmi.WMI()
    else:
        _WMI = None
except Exception:  # noqa: BLE001
    _WMI = None


@dataclass
class CPUInfo:
    name: str = "Unknown CPU"
    usage_percent: float = 0.0
    temperature_c: float | None = None
    clock_mhz: float = 0.0
    core_count: int = 0
    thread_count: int = 0


@dataclass
class GPUInfo:
    name: str = "Unknown GPU"
    usage_percent: float = 0.0
    vram_used_mb: float = 0.0
    vram_total_mb: float = 0.0
    temperature_c: float | None = None
    driver_version: str = "N/A"


@dataclass
class RAMInfo:
    total_gb: float = 0.0
    used_gb: float = 0.0
    available_gb: float = 0.0
    percent: float = 0.0


@dataclass
class StorageInfo:
    drives: list = field(default_factory=list)  # list of dict(letter, used, total, percent)


_cpu_name_cache: str | None = None


def get_cpu_info() -> CPUInfo:
    global _cpu_name_cache
    if _cpu_name_cache is None:
        if cpuinfo:
            try:
                _cpu_name_cache = cpuinfo.get_cpu_info().get("brand_raw", platform.processor())
            except Exception:  # noqa: BLE001
                _cpu_name_cache = platform.processor() or "Unknown CPU"
        else:
            _cpu_name_cache = platform.processor() or "Unknown CPU"

    freq = psutil.cpu_freq()
    temp_c = None
    try:
        temps = psutil.sensors_temperatures()  # not available on Windows via psutil normally
        for entries in temps.values():
            if entries:
                temp_c = entries[0].current
                break
    except Exception:  # noqa: BLE001
        temp_c = None

    return CPUInfo(
        name=_cpu_name_cache,
        usage_percent=psutil.cpu_percent(interval=None),
        temperature_c=temp_c,
        clock_mhz=freq.current if freq else 0.0,
        core_count=psutil.cpu_count(logical=False) or 0,
        thread_count=psutil.cpu_count(logical=True) or 0,
    )


def _get_gpu_info_wmi() -> list[GPUInfo]:
    """Fallback GPU reader for machines where GPUtil (NVIDIA-only) finds
    nothing — AMD/Intel GPUs, or NVIDIA without nvidia-smi on PATH. Pulls the
    adapter name from Win32_VideoController and live utilization from the
    GPU Engine performance counters, which work across vendors."""
    results: list[GPUInfo] = []
    if not _WMI:
        return results
    try:
        controllers = _WMI.Win32_VideoController()
    except Exception:  # noqa: BLE001
        return results

    # Utilization: sum "Utilization Percentage" across all GPU Engine
    # instances (3D, Copy, VideoDecode, etc.) per adapter, capped at 100.
    usage_by_luid: dict[str, float] = {}
    try:
        engines = _WMI.Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine()
        for eng in engines:
            name = getattr(eng, "Name", "") or ""
            luid = name.split("phys_0_eng_")[0] if "phys_0_eng_" in name else name
            util = float(getattr(eng, "UtilizationPercentage", 0) or 0)
            usage_by_luid[luid] = usage_by_luid.get(luid, 0.0) + util
    except Exception:  # noqa: BLE001
        pass

    total_usage = min(100.0, sum(usage_by_luid.values())) if usage_by_luid else 0.0

    for ctrl in controllers:
        name = getattr(ctrl, "Name", None) or "Unknown GPU"
        vram_bytes = getattr(ctrl, "AdapterRAM", None) or 0
        driver = getattr(ctrl, "DriverVersion", None) or "N/A"
        results.append(GPUInfo(
            name=name,
            usage_percent=round(total_usage, 1),
            vram_used_mb=0.0,
            vram_total_mb=round(vram_bytes / (1024 ** 2), 1) if vram_bytes else 0.0,
            temperature_c=None,
            driver_version=driver,
        ))
    return results


def get_gpu_info() -> list[GPUInfo]:
    results: list[GPUInfo] = []
    if GPUtil:
        try:
            for gpu in GPUtil.getGPUs():
                results.append(GPUInfo(
                    name=gpu.name,
                    usage_percent=round(gpu.load * 100, 1),
                    vram_used_mb=gpu.memoryUsed,
                    vram_total_mb=gpu.memoryTotal,
                    temperature_c=gpu.temperature,
                    driver_version=getattr(gpu, "driver", "N/A"),
                ))
        except Exception:  # noqa: BLE001
            pass
    if not results:
        # GPUtil only supports NVIDIA via nvidia-smi — fall back to WMI so
        # AMD/Intel GPUs (and NVIDIA setups without nvidia-smi) still show a
        # real name and usage instead of the "Unknown GPU" placeholder.
        results = _get_gpu_info_wmi()
    if not results:
        results.append(GPUInfo())
    return results


def get_ram_info() -> RAMInfo:
    vm = psutil.virtual_memory()
    gb = 1024 ** 3
    return RAMInfo(
        total_gb=round(vm.total / gb, 1),
        used_gb=round((vm.total - vm.available) / gb, 1),
        available_gb=round(vm.available / gb, 1),
        percent=vm.percent,
    )


def get_storage_info() -> StorageInfo:
    drives = []
    for part in psutil.disk_partitions(all=False):
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except (PermissionError, OSError):
            continue
        gb = 1024 ** 3
        drives.append({
            "letter": part.device,
            "used_gb": round(usage.used / gb, 1),
            "total_gb": round(usage.total / gb, 1),
            "percent": usage.percent,
        })
    return StorageInfo(drives=drives)


def get_network_io():
    return psutil.net_io_counters()


_last_net = {"t": time.time(), "sent": 0, "recv": 0}


def get_network_throughput_kbps() -> tuple[float, float]:
    """Returns (upload_kbps, download_kbps) sampled since the last call."""
    io = psutil.net_io_counters()
    now = time.time()
    dt = max(now - _last_net["t"], 0.001)
    up = max((io.bytes_sent - _last_net["sent"]) / 1024 / dt, 0) if _last_net["sent"] else 0
    down = max((io.bytes_recv - _last_net["recv"]) / 1024 / dt, 0) if _last_net["recv"] else 0
    _last_net.update(t=now, sent=io.bytes_sent, recv=io.bytes_recv)
    return round(up, 1), round(down, 1)


def compute_frontier_score(cpu: CPUInfo, ram: RAMInfo, tweaks_applied: int, tweaks_total: int) -> dict:
    """A lightweight, deterministic heuristic score for the dashboard — not a
    benchmark, just a friendly composite of headroom + how many tweaks are on."""
    optimization = round(100 * (tweaks_applied / max(tweaks_total, 1)))
    headroom = max(0, 100 - cpu.usage_percent)
    gaming = round(min(100, headroom * 0.6 + optimization * 0.4))
    latency = round(min(100, 100 - (ram.percent * 0.3) - (cpu.usage_percent * 0.2)))
    return {
        "gaming": max(0, min(100, gaming)),
        "latency": max(0, min(100, latency)),
        "optimization": max(0, min(100, optimization)),
    }
