"""
FRONTIER PREMIUM - Modular Tweak Engine
==========================================
Data-driven registry of Windows optimization tweaks. Each Tweak knows how to
apply() and revert() itself. Real changes only ever run on Windows (os.name
== "nt") and only after the user has triggered them from the UI; on any other
platform the engine runs in a fully functional simulation mode so the app is
demoable cross-platform.

Every apply() call is logged to the SQLite database (core.database) and the
result is persisted to the JSON config (core.config) so toggle states survive
restarts.
"""
from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional

from core import database
from core.config import config

IS_WINDOWS = os.name == "nt"


class TweakCategory(Enum):
    GENERAL = "General"
    CPU = "CPU"
    GPU = "GPU"
    RAM = "RAM"
    INPUT = "Input"
    STORAGE = "Storage"
    NETWORK = "Network"
    ADVANCED = "Advanced"


def _run_reg(args: list[str]) -> tuple[bool, str]:
    """Run a `reg.exe` command. Returns (success, output)."""
    if not IS_WINDOWS:
        return True, "[simulated] reg " + " ".join(args)
    try:
        result = subprocess.run(
            ["reg.exe", *args],
            capture_output=True, text=True, timeout=15,
        )
        ok = result.returncode == 0
        return ok, (result.stdout or result.stderr).strip()
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def _run_powercfg(args: list[str]) -> tuple[bool, str]:
    if not IS_WINDOWS:
        return True, "[simulated] powercfg " + " ".join(args)
    try:
        result = subprocess.run(
            ["powercfg.exe", *args], capture_output=True, text=True, timeout=15
        )
        ok = result.returncode == 0
        return ok, (result.stdout or result.stderr).strip()
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def _run_powershell(script: str) -> tuple[bool, str]:
    if not IS_WINDOWS:
        return True, "[simulated] powershell: " + script[:80]
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, text=True, timeout=20,
        )
        ok = result.returncode == 0
        return ok, (result.stdout or result.stderr).strip()
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


@dataclass
class Tweak:
    id: str
    label: str
    description: str
    category: TweakCategory
    apply_fn: Callable[[], tuple[bool, str]]
    revert_fn: Optional[Callable[[], tuple[bool, str]]] = None
    requires_restart: bool = False
    risk: str = "safe"          # safe | moderate | advanced

    def is_enabled(self) -> bool:
        return bool(config.get("tweaks", self.id, default=False))

    def apply(self) -> tuple[bool, str]:
        ok, output = self.apply_fn()
        config.set("tweaks", self.id, ok)
        database.log_tweak(self.id, self.label, "applied", ok)
        database.log(
            self.category.value, f"Applied '{self.label}'" + ("" if ok else f" — FAILED: {output}"),
            level="success" if ok else "error",
        )
        return ok, output

    def revert(self) -> tuple[bool, str]:
        if not self.revert_fn:
            return False, "No revert handler defined for this tweak."
        ok, output = self.revert_fn()
        config.set("tweaks", self.id, not ok)
        database.log_tweak(self.id, self.label, "reverted", ok)
        database.log(
            self.category.value, f"Reverted '{self.label}'" + ("" if ok else f" — FAILED: {output}"),
            level="success" if ok else "error",
        )
        return ok, output


# ---------------------------------------------------------------------------
# Registry-key helper factories — build matched apply/revert closures
# ---------------------------------------------------------------------------

def reg_dword_tweak(hive: str, key: str, value_name: str, on_value: int, off_value: int):
    def _apply():
        return _run_reg(["add", f"{hive}\\{key}", "/v", value_name, "/t", "REG_DWORD",
                          "/d", str(on_value), "/f"])

    def _revert():
        return _run_reg(["add", f"{hive}\\{key}", "/v", value_name, "/t", "REG_DWORD",
                          "/d", str(off_value), "/f"])

    return _apply, _revert


# ---------------------------------------------------------------------------
# GENERAL / WINDOWS TWEAKS
# ---------------------------------------------------------------------------
_general_tweaks: list[Tweak] = []


def _add_general():
    defs = [
        ("gen_disable_notifications", "Disable Notifications",
         "Turns off Windows notification toast popups system-wide.",
         "HKCU", r"Software\Microsoft\Windows\CurrentVersion\PushNotifications",
         "ToastEnabled", 0, 1),
        ("gen_disable_animations", "Disable Animations",
         "Disables window and menu animation effects for a snappier feel.",
         "HKCU", r"Control Panel\Desktop\WindowMetrics", "MinAnimate", 0, 1),
        ("gen_disable_ceip", "Disable Customer Experience Improvement Program",
         "Stops CEIP diagnostic data collection.",
         "HKLM", r"SOFTWARE\Policies\Microsoft\SQMClient\Windows", "CEIPEnable", 0, 1),
        ("gen_disable_transparency", "Disable Transparency Effects",
         "Disables the frosted-glass transparency effect for better GPU headroom.",
         "HKCU", r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
         "EnableTransparency", 0, 1),
        ("gen_disable_search_bing", "Disable Windows Search Web Results",
         "Keeps Start Menu search local-only, removing Bing web results.",
         "HKCU", r"Software\Microsoft\Windows\CurrentVersion\Search", "BingSearchEnabled", 0, 1),
        ("gen_disable_background_apps", "Disable Background Apps",
         "Prevents UWP apps from running in the background.",
         "HKCU", r"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications",
         "GlobalUserDisabled", 1, 0),
        ("gen_disable_copilot", "Disable Windows Copilot",
         "Removes the Copilot button and disables the assistant.",
         "HKCU", r"Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", 1, 0),
        ("gen_disable_gamedvr", "Disable Game DVR / Xbox Game Bar Capture",
         "Disables background game recording that can eat frame time.",
         "HKCU", r"System\GameConfigStore", "GameDVR_Enabled", 0, 1),
        ("gen_enable_game_mode", "Enable Windows Game Mode",
         "Ensures Windows Game Mode is turned on for foreground game priority.",
         "HKCU", r"Software\Microsoft\GameBar", "AutoGameModeEnabled", 1, 0),
        ("gen_disable_startup_delay", "Disable Startup App Delay",
         "Removes the artificial delay before startup apps launch.",
         "HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize",
         "StartupDelayInMSec", 0, 1),
        ("gen_disable_thumbnail_cache", "Disable Thumbnail Cache",
         "Stops Explorer from caching thumbnails to disk.",
         "HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",
         "DisableThumbnailCache", 1, 0),
        ("gen_optimize_visual_effects", "Optimize Visual Effects for Performance",
         "Sets Windows visual effects to 'Adjust for best performance'.",
         "HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects",
         "VisualFXSetting", 2, 0),
    ]
    for tid, label, desc, hive, key, val, on, off in defs:
        a, r = reg_dword_tweak(hive, key, val, on, off)
        _general_tweaks.append(Tweak(tid, label, desc, TweakCategory.GENERAL, a, r))


_add_general()


# ---------------------------------------------------------------------------
# CPU TWEAKS
# ---------------------------------------------------------------------------
_cpu_tweaks: list[Tweak] = []


def _cpu_disable_c_states():
    return _run_powercfg([
        "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "IDLESTATES", "1"
    ]) and _run_powercfg(["/setactive", "SCHEME_CURRENT"])


def _cpu_enable_c_states():
    return _run_powercfg([
        "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "IDLESTATES", "0"
    ])


def _cpu_min_max_100():
    ok1, out1 = _run_powercfg(["/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMIN", "100"])
    ok2, out2 = _run_powercfg(["/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMAX", "100"])
    return (ok1 and ok2), out1 + "\n" + out2


def _cpu_restore_min_max():
    ok1, out1 = _run_powercfg(["/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMIN", "5"])
    ok2, out2 = _run_powercfg(["/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMAX", "100"])
    return (ok1 and ok2), out1 + "\n" + out2


_cpu_tweaks.append(Tweak(
    "cpu_disable_c_states", "Disable CPU C-States",
    "Prevents deep idle states for lower input/frame latency (may increase idle temps).",
    TweakCategory.CPU, _cpu_disable_c_states, _cpu_enable_c_states, risk="moderate",
))
_cpu_tweaks.append(Tweak(
    "cpu_min_max_100", "Processor Min/Max 100%",
    "Locks minimum and maximum processor state to 100% on the active power plan.",
    TweakCategory.CPU, _cpu_min_max_100, _cpu_restore_min_max, risk="moderate",
))
_cpu_tweaks.append(Tweak(
    "cpu_power_throttling_off", "Disable CPU Power Throttling",
    "Disables Windows 'Power Throttling' for foreground applications.",
    TweakCategory.CPU,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling",
                      "PowerThrottlingOff", 1, 0),
))
_cpu_tweaks.append(Tweak(
    "cpu_win32_priority_separation", "Optimize Scheduler (Win32PrioritySeparation)",
    "Tunes the CPU scheduler to favor foreground app responsiveness.",
    TweakCategory.CPU,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Control\PriorityControl",
                      "Win32PrioritySeparation", 38, 2),
))


# ---------------------------------------------------------------------------
# GPU TWEAKS (vendor-neutral registry keys; NVIDIA-specific ones guarded)
# ---------------------------------------------------------------------------
_gpu_tweaks: list[Tweak] = []
_gpu_tweaks.append(Tweak(
    "gpu_disable_fse_optim", "Disable Fullscreen Optimizations Globally",
    "Reduces compositor overhead so exclusive fullscreen games get direct flip.",
    TweakCategory.GPU,
    *reg_dword_tweak("HKCU", r"System\GameConfigStore", "GameDVR_FSEBehaviorMode", 2, 0),
))
_gpu_tweaks.append(Tweak(
    "gpu_hwgpuscheduling", "Enable Hardware-Accelerated GPU Scheduling",
    "Offloads GPU scheduling to hardware for reduced latency (needs restart).",
    TweakCategory.GPU,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers",
                      "HwSchMode", 2, 1),
    requires_restart=True,
))
_gpu_tweaks.append(Tweak(
    "gpu_disable_telemetry_nv", "Disable NVIDIA Telemetry Services",
    "Disables NvTelemetryContainer and related background telemetry tasks.",
    TweakCategory.GPU,
    lambda: _run_powershell(
        "Get-Service -Name 'NvTelemetryContainer' -ErrorAction SilentlyContinue | Stop-Service -Force; "
        "Set-Service -Name 'NvTelemetryContainer' -StartupType Disabled -ErrorAction SilentlyContinue"
    ),
    lambda: _run_powershell(
        "Set-Service -Name 'NvTelemetryContainer' -StartupType Manual -ErrorAction SilentlyContinue"
    ),
))
_gpu_tweaks.append(Tweak(
    "gpu_disable_driver_updates", "Disable Driver Update Checks via Windows Update",
    "Prevents Windows Update from silently replacing GPU drivers.",
    TweakCategory.GPU,
    *reg_dword_tweak("HKLM", r"SOFTWARE\Policies\Microsoft\Windows\DriverSearching",
                      "SearchOrderConfig", 0, 1),
))
_gpu_tweaks.append(Tweak(
    "gpu_disable_power_saving_display", "Disable Display Power Saving",
    "Keeps GPU output in max performance rather than adaptive power states.",
    TweakCategory.GPU,
    *reg_dword_tweak("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects",
                      "DisplayPowerSaving", 0, 1),
))


# ---------------------------------------------------------------------------
# RAM TWEAKS
# ---------------------------------------------------------------------------
_ram_tweaks: list[Tweak] = []
_ram_tweaks.append(Tweak(
    "ram_disable_prefetch", "Disable Prefetch (SSD systems)",
    "Disables Prefetch/SuperFetch, recommended for systems on NVMe/SSD storage.",
    TweakCategory.RAM,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters",
                      "EnablePrefetcher", 0, 3),
))
_ram_tweaks.append(Tweak(
    "ram_disable_superfetch", "Disable SysMain (SuperFetch) Service",
    "Stops the SysMain service that pre-loads apps into memory.",
    TweakCategory.RAM,
    lambda: _run_powershell("Stop-Service -Name SysMain -Force -ErrorAction SilentlyContinue; "
                             "Set-Service -Name SysMain -StartupType Disabled -ErrorAction SilentlyContinue"),
    lambda: _run_powershell("Set-Service -Name SysMain -StartupType Automatic -ErrorAction SilentlyContinue; "
                             "Start-Service -Name SysMain -ErrorAction SilentlyContinue"),
))
_ram_tweaks.append(Tweak(
    "ram_disable_page_combining", "Disable Memory Page Combining",
    "Stops the memory manager from combining identical pages, trading RAM for CPU headroom.",
    TweakCategory.RAM,
    lambda: _run_powershell("Disable-MMAgent -PageCombining -ErrorAction SilentlyContinue"),
    lambda: _run_powershell("Enable-MMAgent -PageCombining -ErrorAction SilentlyContinue"),
))
_ram_tweaks.append(Tweak(
    "ram_svchost_split", "Optimize SVCHost Process Splitting",
    "Tunes the service-host split threshold based on installed RAM.",
    TweakCategory.RAM,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Control", "SvcHostSplitThresholdInKB",
                      0x0F000000, 0x00380000),
))


# ---------------------------------------------------------------------------
# INPUT TWEAKS
# ---------------------------------------------------------------------------
_input_tweaks: list[Tweak] = []
_input_tweaks.append(Tweak(
    "input_disable_mouse_accel", "Disable Mouse Acceleration",
    "Forces 1:1 raw mouse movement by zeroing MouseSpeed/Threshold values.",
    TweakCategory.INPUT,
    lambda: all(r[0] for r in [
        _run_reg(["add", r"HKCU\Control Panel\Mouse", "/v", "MouseSpeed", "/t", "REG_SZ", "/d", "0", "/f"]),
        _run_reg(["add", r"HKCU\Control Panel\Mouse", "/v", "MouseThreshold1", "/t", "REG_SZ", "/d", "0", "/f"]),
        _run_reg(["add", r"HKCU\Control Panel\Mouse", "/v", "MouseThreshold2", "/t", "REG_SZ", "/d", "0", "/f"]),
    ]) and (True, "applied") or (False, "one or more reg writes failed"),
    lambda: _run_reg(["add", r"HKCU\Control Panel\Mouse", "/v", "MouseSpeed", "/t", "REG_SZ", "/d", "1", "/f"]),
))
_input_tweaks.append(Tweak(
    "input_disable_usb_suspend", "Disable USB Selective Suspend",
    "Stops Windows from power-suspending USB devices (mice, keyboards, controllers).",
    TweakCategory.INPUT,
    lambda: _run_powercfg(["/setacvalueindex", "SCHEME_CURRENT", "2a737441-1930-4402-8d77-b2bebba308a3",
                            "48e6b7a6-50f5-4782-a5d4-53bb8f07e226", "0"]),
    lambda: _run_powercfg(["/setacvalueindex", "SCHEME_CURRENT", "2a737441-1930-4402-8d77-b2bebba308a3",
                            "48e6b7a6-50f5-4782-a5d4-53bb8f07e226", "1"]),
))
_input_tweaks.append(Tweak(
    "input_keyboard_delay", "Reduce Keyboard Repeat Delay",
    "Sets the fastest available keyboard repeat delay/rate for competitive input.",
    TweakCategory.INPUT,
    lambda: all(r[0] for r in [
        _run_reg(["add", r"HKCU\Control Panel\Keyboard", "/v", "KeyboardDelay", "/t", "REG_SZ", "/d", "0", "/f"]),
        _run_reg(["add", r"HKCU\Control Panel\Keyboard", "/v", "KeyboardSpeed", "/t", "REG_SZ", "/d", "31", "/f"]),
    ]) and (True, "applied") or (False, "failed"),
    lambda: _run_reg(["add", r"HKCU\Control Panel\Keyboard", "/v", "KeyboardDelay", "/t", "REG_SZ", "/d", "1", "/f"]),
))


# ---------------------------------------------------------------------------
# STORAGE TWEAKS
# ---------------------------------------------------------------------------
_storage_tweaks: list[Tweak] = []
_storage_tweaks.append(Tweak(
    "storage_disable_hdd_parking", "Disable HDD Head Parking",
    "Stops aggressive AAM head-parking that causes stutter on spinning drives.",
    TweakCategory.STORAGE,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Services\storahci\Parameters\Device",
                      "TreatAsInternalPort", 0, 1),
))
_storage_tweaks.append(Tweak(
    "storage_ntfs_optimize", "Optimize NTFS (disable last access timestamp)",
    "Disables NTFS last-access-time updates, reducing small write overhead.",
    TweakCategory.STORAGE,
    lambda: _run_powershell("fsutil behavior set disablelastaccess 1"),
    lambda: _run_powershell("fsutil behavior set disablelastaccess 0"),
))
_storage_tweaks.append(Tweak(
    "storage_disable_idle", "Disable Storage Device Idle Timeouts",
    "Prevents drives from spinning down / entering low-power idle mid-session.",
    TweakCategory.STORAGE,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Control\Power", "HiberbootEnabled", 0, 1),
))


# ---------------------------------------------------------------------------
# NETWORK TWEAKS
# ---------------------------------------------------------------------------
_network_tweaks: list[Tweak] = []
_network_tweaks.append(Tweak(
    "net_disable_nagle", "Disable Nagle's Algorithm (TCP ACK)",
    "Reduces small-packet latency for competitive online games.",
    TweakCategory.NETWORK,
    lambda: _run_powershell(
        "Get-NetAdapter | ForEach-Object { "
        "Set-NetTCPSetting -SettingName InternetCustom -ErrorAction SilentlyContinue }"
    ),
    None,
    risk="moderate",
))
_network_tweaks.append(Tweak(
    "net_disable_throttling", "Disable Network Throttling Index",
    "Removes the multimedia-class scheduler's network throttle cap.",
    TweakCategory.NETWORK,
    *reg_dword_tweak("HKLM", r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
                      "NetworkThrottlingIndex", 0xFFFFFFFF, 10),
))
_network_tweaks.append(Tweak(
    "net_disable_delivery_optim", "Disable Delivery Optimization (P2P Updates)",
    "Stops Windows Update from uploading/downloading updates peer-to-peer.",
    TweakCategory.NETWORK,
    *reg_dword_tweak("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config",
                      "DODownloadMode", 0, 1),
))
_network_tweaks.append(Tweak(
    "net_disable_ipv6", "Disable IPv6 (where unsupported)",
    "Disables IPv6 binding on adapters to avoid fallback-negotiation latency.",
    TweakCategory.NETWORK,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters",
                      "DisabledComponents", 0xFF, 0),
    risk="moderate",
))
_network_tweaks.append(Tweak(
    "net_tcp_ack_freq", "Optimize TCP ACK Frequency",
    "Tunes TcpAckFrequency for faster acknowledgement on wired connections.",
    TweakCategory.NETWORK,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Interfaces", "TcpAckFrequency", 1, 2),
    risk="advanced",
))


# ---------------------------------------------------------------------------
# ADVANCED TWEAKS
# ---------------------------------------------------------------------------
_advanced_tweaks: list[Tweak] = []
_advanced_tweaks.append(Tweak(
    "adv_core_isolation", "Toggle Core Isolation (Memory Integrity)",
    "Turns off HVCI-based memory integrity checks, which can cost several % CPU in games.",
    TweakCategory.ADVANCED,
    *reg_dword_tweak("HKLM", r"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity",
                      "Enabled", 0, 1),
    risk="advanced",
))
_advanced_tweaks.append(Tweak(
    "adv_disable_uac", "Lower UAC Notification Level",
    "Reduces UAC prompt frequency (does not fully disable UAC protection).",
    TweakCategory.ADVANCED,
    *reg_dword_tweak("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
                      "ConsentPromptBehaviorAdmin", 0, 5),
    risk="advanced",
))
_advanced_tweaks.append(Tweak(
    "adv_smb_signing", "Disable SMB Auto-Tuning Overhead",
    "Tunes SMB client parameters for local LAN game-file transfer speed.",
    TweakCategory.ADVANCED,
    lambda: _run_powershell("Set-SmbClientConfiguration -EnableBandwidthThrottling $false -Force"),
    lambda: _run_powershell("Set-SmbClientConfiguration -EnableBandwidthThrottling $true -Force"),
    risk="advanced",
))
_advanced_tweaks.append(Tweak(
    "adv_timer_resolution", "Set High-Precision Timer Resolution (0.5ms)",
    "Requests a finer system timer resolution for smoother frame pacing.",
    TweakCategory.ADVANCED,
    lambda: _run_powershell("bcdedit /set useplatformclock false; bcdedit /set disabledynamictick yes"),
    lambda: _run_powershell("bcdedit /deletevalue useplatformclock; bcdedit /set disabledynamictick no"),
    requires_restart=True, risk="advanced",
))
_advanced_tweaks.append(Tweak(
    "adv_msi_mode_hint", "MSI Mode Manager (per-device, see Advanced page)",
    "Opens the guided MSI (Message-Signaled Interrupts) manager for GPU/audio/NVMe/USB devices.",
    TweakCategory.ADVANCED,
    lambda: (True, "Use the MSI Mode Manager panel to toggle per-device."),
    None,
))


# --- FRONTIER FREE: trimmed catalog -----------------------------------------
# Free edition ships a much smaller, compact tweak set: Advanced tweaks are
# a Premium-only category, and every remaining category is capped to its
# first 2 entries so Free stays a lightweight "quick tune" tool rather than
# the full optimization suite.
FREE_EDITION = True
_MAX_TWEAKS_PER_CATEGORY = 2

if FREE_EDITION:
    _advanced_tweaks = []
    _general_tweaks = _general_tweaks[:_MAX_TWEAKS_PER_CATEGORY]
    _cpu_tweaks = _cpu_tweaks[:_MAX_TWEAKS_PER_CATEGORY]
    _gpu_tweaks = _gpu_tweaks[:_MAX_TWEAKS_PER_CATEGORY]
    _ram_tweaks = _ram_tweaks[:_MAX_TWEAKS_PER_CATEGORY]
    _input_tweaks = _input_tweaks[:_MAX_TWEAKS_PER_CATEGORY]
    _storage_tweaks = _storage_tweaks[:_MAX_TWEAKS_PER_CATEGORY]
    _network_tweaks = _network_tweaks[:_MAX_TWEAKS_PER_CATEGORY]

ALL_TWEAKS: list[Tweak] = (
    _general_tweaks + _cpu_tweaks + _gpu_tweaks + _ram_tweaks +
    _input_tweaks + _storage_tweaks + _network_tweaks + _advanced_tweaks
)

TWEAKS_BY_ID = {t.id: t for t in ALL_TWEAKS}
TWEAKS_BY_CATEGORY: dict[TweakCategory, list[Tweak]] = {}
for _t in ALL_TWEAKS:
    TWEAKS_BY_CATEGORY.setdefault(_t.category, []).append(_t)


def apply_all(category: Optional[TweakCategory] = None, progress_cb: Optional[Callable[[str, int, int], None]] = None):
    """Apply every tweak (optionally scoped to one category). Used by One-Click Optimize."""
    tweaks = TWEAKS_BY_CATEGORY.get(category, ALL_TWEAKS) if category else ALL_TWEAKS
    results = []
    total = len(tweaks)
    for i, tweak in enumerate(tweaks, start=1):
        ok, output = tweak.apply()
        results.append((tweak, ok, output))
        if progress_cb:
            progress_cb(tweak.label, i, total)
    config.set("stats", "optimizations_run", config.get("stats", "optimizations_run", default=0) + 1)
    return results
