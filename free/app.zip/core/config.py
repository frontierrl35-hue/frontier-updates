"""
FRONTIER PREMIUM - Configuration System
Persists tweak states, theme settings and app preferences to a JSON file
in the user's local app data folder.
"""
import json
import os
from pathlib import Path
from typing import Any

APP_NAME = "FrontierFree"


def get_app_data_dir() -> Path:
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA", str(Path.home()))
    else:
        base = str(Path.home() / ".local" / "share")
    path = Path(base) / APP_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


DEFAULT_CONFIG = {
    "version": "1.0.0",
    "first_run": True,
    "theme": {
        "red_intensity": 1.0,
        "animations_enabled": True,
        "compact_mode": False,
    },
    "tweaks": {},          # tweak_id -> bool (applied state)
    "debloat": {},         # app_id -> bool (removed state)
    "game_mode": {
        "enabled": False,
        "auto_detect": True,
        "watched_games": [
            "FortniteClient-Win64-Shipping.exe",
            "RocketLeague.exe",
            "VALORANT-Win64-Shipping.exe",
            "cs2.exe",
            "GTA5.exe",
            "Minecraft.exe",
        ],
    },
    "network_priority_apps": [],   # list of {"name": str, "path": str}
    "stats": {
        "optimizations_run": 0,
        "last_optimize_ts": None,
        "frontier_score": {"gaming": 0, "latency": 0, "optimization": 0},
    },
}


class ConfigManager:
    """Loads / saves / mutates the JSON config with safe defaults merge."""

    def __init__(self):
        self.path = get_app_data_dir() / "config.json"
        self.data: dict[str, Any] = {}
        self.load()

    def load(self):
        if self.path.exists():
            try:
                with open(self.path, "r", encoding="utf-8") as fh:
                    loaded = json.load(fh)
            except (json.JSONDecodeError, OSError):
                loaded = {}
        else:
            loaded = {}
        self.data = self._merge_defaults(DEFAULT_CONFIG, loaded)
        self.save()

    def _merge_defaults(self, defaults: dict, loaded: dict) -> dict:
        merged = dict(defaults)
        for key, value in loaded.items():
            if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
                merged[key] = self._merge_defaults(merged[key], value)
            else:
                merged[key] = value
        return merged

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as fh:
                json.dump(self.data, fh, indent=2)
        except OSError:
            pass

    def get(self, *keys, default=None):
        node = self.data
        for k in keys:
            if isinstance(node, dict) and k in node:
                node = node[k]
            else:
                return default
        return node

    def set(self, *keys_and_value):
        *keys, value = keys_and_value
        node = self.data
        for k in keys[:-1]:
            node = node.setdefault(k, {})
        node[keys[-1]] = value
        self.save()


config = ConfigManager()
