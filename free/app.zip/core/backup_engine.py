"""
FRONTIER PREMIUM - Backups & Fixes
Creates a Windows System Restore point before tweaks are applied, and wraps
common built-in repair commands (DISM / SFC / service restarts) behind
friendly one-click fix cards.
"""
from __future__ import annotations

from core import database
from core.tweak_engine import _run_powershell, IS_WINDOWS


def create_restore_point(label: str = "Before Frontier Free") -> tuple[bool, str]:
    ok, out = _run_powershell(
        f"Checkpoint-Computer -Description '{label}' -RestorePointType 'MODIFY_SETTINGS'"
    )
    database.log_restore_point(label, out)
    database.log("Backup", f"Created restore point: {label}", "success" if ok else "error")
    return ok, out or "Restore point created."


FIX_TOOLS = {
    "audio": (
        "Audio Repair",
        "Restarts Windows Audio services and resets the default endpoint.",
        "Restart-Service -Name AudioSrv,AudioEndpointBuilder -Force -ErrorAction SilentlyContinue",
    ),
    "bluetooth": (
        "Bluetooth Repair",
        "Restarts the Bluetooth support service stack.",
        "Restart-Service -Name bthserv -Force -ErrorAction SilentlyContinue",
    ),
    "network": (
        "Network Repair",
        "Flushes DNS, resets Winsock and releases/renews the IP lease.",
        "ipconfig /flushdns; netsh winsock reset; ipconfig /release; ipconfig /renew",
    ),
    "nvidia": (
        "NVIDIA Repair",
        "Restarts the NVIDIA display container service.",
        "Restart-Service -Name NVDisplay.ContainerLocalSystem -Force -ErrorAction SilentlyContinue",
    ),
    "store": (
        "Microsoft Store Repair",
        "Resets the Store app's local cache via wsreset.",
        "wsreset.exe",
    ),
    "discord": (
        "Discord Repair",
        "Clears the Discord cache folders to fix update/overlay issues.",
        "Remove-Item -Recurse -Force \"$env:APPDATA\\discord\\Cache\" -ErrorAction SilentlyContinue",
    ),
    "adobe": (
        "Adobe Repair",
        "Restarts the Adobe Genuine/licensing background service.",
        "Restart-Service -Name AdobeARMservice -Force -ErrorAction SilentlyContinue",
    ),
    "amd": (
        "AMD Service Repair",
        "Restarts the AMD External Events / driver support service.",
        "Restart-Service -Name AMD_External_Events_Utility -Force -ErrorAction SilentlyContinue",
    ),
}


def run_fix(fix_id: str) -> tuple[bool, str]:
    entry = FIX_TOOLS.get(fix_id)
    if not entry:
        return False, "Unknown fix tool."
    label, _desc, script = entry
    ok, out = _run_powershell(script)
    database.log("Fix Tools", f"Ran {label}", "success" if ok else "error")
    return ok, out or f"{label} completed."
