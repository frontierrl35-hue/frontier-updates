"""
FRONTIER PREMIUM - Headless Optimize CLI
Applies every registered tweak from the console, with progress output.
Used by QUICK_OPTIMIZE.bat for a no-UI "just optimize it" path — the same
engine and logging the GUI's ⚡ OPTIMIZE PC button uses.
"""
import sys

from core import backup_engine, tweak_engine


def main():
    print("=" * 55)
    print("  FRONTIER FREE 1.0 - Quick Optimize (headless)")
    print("=" * 55)

    if not tweak_engine.IS_WINDOWS:
        print("\n[!] Not running on Windows — tweaks will run in SIMULATION")
        print("    mode only (no real system changes will be made).\n")

    print("[1/3] Creating restore point...")
    ok, msg = backup_engine.create_restore_point("Before Frontier Free (Quick Optimize)")
    print("      OK" if ok else f"      SKIPPED: {msg}")

    print(f"[2/3] Applying {len(tweak_engine.ALL_TWEAKS)} tweaks...")

    def progress(label, i, total):
        print(f"      ({i}/{total}) {label}")

    results = tweak_engine.apply_all(progress_cb=progress)
    success = sum(1 for _, ok, _ in results if ok)
    failed = [(t, msg) for t, ok, msg in results if not ok]

    print(f"[3/3] Done — {success}/{len(results)} tweaks applied successfully.")
    if failed:
        print("\n  The following tweaks failed:")
        for t, msg in failed:
            print(f"   - {t.label}: {msg}")

    print("\n  A full log is available from inside the app: Support -> Export Report.")
    print("=" * 55)


if __name__ == "__main__":
    main()
