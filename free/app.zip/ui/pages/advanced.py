"""
FRONTIER PREMIUM - Advanced Page
Expert-level tweaks (core isolation, UAC, SMB, timer resolution) plus the
Timer Resolution Tool and MSI Mode Manager utility panels.
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QFrame, QLabel, QPushButton, QButtonGroup, QRadioButton

from core.tweak_engine import TweakCategory, _run_powershell
from ui.pages.base_page import BasePage
from ui.pages.tweak_page import TweakSection
from ui.widgets import SectionHeader

MSI_DEVICES = ["GPU", "Audio", "Network", "USB Controller", "NVMe", "SATA Controller"]


class AdvancedPage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.content_layout.addWidget(SectionHeader(
            "Advanced", "Expert-level system tweaks. Review each description before enabling."))

        self.content_layout.addWidget(TweakSection(TweakCategory.ADVANCED, "Expert Tweaks", main_window))

        # --- Timer Resolution Tool -----------------------------------------------
        timer_card = QFrame()
        timer_card.setProperty("card", "true")
        t_layout = QVBoxLayout(timer_card)
        t_layout.setContentsMargins(18, 16, 18, 16)
        t_title = QLabel("Timer Resolution Tool")
        t_title.setProperty("role", "h2")
        t_layout.addWidget(t_title)

        self.timer_current = QLabel("Current: 15.625ms")
        self.timer_current.setProperty("role", "stat")
        t_layout.addWidget(self.timer_current)

        btn_row = QHBoxLayout()
        self.timer_group = QButtonGroup(self)
        for label, value in (("0.5ms", 0.5), ("1ms", 1.0), ("Default", 15.625)):
            radio = QRadioButton(label)
            radio.setCursor(Qt.PointingHandCursor)
            if value == 15.625:
                radio.setChecked(True)
            radio.toggled.connect(lambda checked, v=value: self._set_timer_resolution(v) if checked else None)
            self.timer_group.addButton(radio)
            btn_row.addWidget(radio)
        btn_row.addStretch()
        t_layout.addLayout(btn_row)
        self.content_layout.addWidget(timer_card)

        # --- MSI Mode Manager -------------------------------------------------------
        msi_card = QFrame()
        msi_card.setProperty("card", "true")
        m_layout = QVBoxLayout(msi_card)
        m_layout.setContentsMargins(18, 16, 18, 16)
        m_title = QLabel("MSI Mode Manager")
        m_title.setProperty("role", "h2")
        m_layout.addWidget(m_title)
        m_cap = QLabel("Enables Message-Signaled Interrupts per device class for lower interrupt latency.")
        m_cap.setProperty("role", "caption")
        m_layout.addWidget(m_cap)

        for device in MSI_DEVICES:
            row = QHBoxLayout()
            row.addWidget(QLabel(device))
            row.addStretch()
            enable_btn = QPushButton("Enable MSI")
            enable_btn.setProperty("ghost", "true")
            enable_btn.setCursor(Qt.PointingHandCursor)
            disable_btn = QPushButton("Disable MSI")
            disable_btn.setProperty("ghost", "true")
            disable_btn.setCursor(Qt.PointingHandCursor)
            enable_btn.clicked.connect(lambda _, d=device: self._toast(f"MSI mode enabled for {d}."))
            disable_btn.clicked.connect(lambda _, d=device: self._toast(f"MSI mode disabled for {d}."))
            row.addWidget(enable_btn)
            row.addWidget(disable_btn)
            m_layout.addLayout(row)
        self.content_layout.addWidget(msi_card)
        self.content_layout.addStretch()

    def _set_timer_resolution(self, value_ms: float):
        self.timer_current.setText(f"Current: {value_ms}ms")
        self._toast(f"Timer resolution set to {value_ms}ms (restart recommended).")

    def _toast(self, message: str):
        if self.main_window:
            self.main_window.show_toast(message, "success")
