"""
FRONTIER PREMIUM - Hardware Page
Stacks the CPU, GPU, RAM, Storage and Input tweak sections with live
hardware readouts at the top of each block.
"""
from PySide6.QtWidgets import QLabel, QHBoxLayout, QFrame

from core.tweak_engine import TweakCategory
from core import system_info
from ui.pages.base_page import BasePage
from ui.pages.tweak_page import TweakSection
from ui.widgets import SectionHeader


class HardwarePage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.content_layout.addWidget(SectionHeader(
            "Hardware", "Per-component tweaks for CPU, GPU, RAM, Storage and Input devices"))

        cpu = system_info.get_cpu_info()
        gpus = system_info.get_gpu_info()

        self.content_layout.addWidget(self._info_strip(f"Detected CPU: {cpu.name}  ·  "
                                                         f"{cpu.core_count}C/{cpu.thread_count}T"))
        self.content_layout.addWidget(TweakSection(TweakCategory.CPU, "CPU", main_window))

        gpu_name = gpus[0].name if gpus else "Unknown GPU"
        self.content_layout.addWidget(self._info_strip(f"Detected GPU: {gpu_name}"))
        self.content_layout.addWidget(TweakSection(TweakCategory.GPU, "GPU", main_window))

        self.content_layout.addWidget(TweakSection(TweakCategory.RAM, "RAM", main_window))
        self.content_layout.addWidget(TweakSection(TweakCategory.STORAGE, "Storage", main_window))
        self.content_layout.addWidget(TweakSection(TweakCategory.INPUT, "Input (Keyboard / Mouse / Controller)", main_window))
        self.content_layout.addStretch()

    @staticmethod
    def _info_strip(text: str) -> QFrame:
        frame = QFrame()
        frame.setProperty("cardSecondary", "true")
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(14, 8, 14, 8)
        lbl = QLabel(text)
        lbl.setProperty("role", "caption")
        layout.addWidget(lbl)
        return frame
