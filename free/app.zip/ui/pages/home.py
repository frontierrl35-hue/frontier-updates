"""
FRONTIER PREMIUM - Home Dashboard
Task-Manager-style live monitor (CPU / GPU / RAM / Storage), rolling
performance graphs, the Frontier Score composite, and the big One-Click
Optimize button that runs every tweak in the engine with a staged progress
overlay.
"""
from PySide6.QtCore import Qt, QTimer, QThread, Signal
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QFrame, QLabel, QGridLayout, QProgressBar

from core import system_info, tweak_engine
from core.theme import Colors
from ui.pages.base_page import BasePage
from ui.widgets import StatCard, LiveGraph, GlowButton, SectionHeader, ToastNotification


class OptimizeWorker(QThread):
    progress = Signal(str, int, int)
    finished_ok = Signal(int, int)

    def run(self):
        results = tweak_engine.apply_all(progress_cb=lambda label, i, total: self.progress.emit(label, i, total))
        success = sum(1 for _, ok, _ in results if ok)
        self.finished_ok.emit(success, len(results))


class HomePage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window

        header_row = QHBoxLayout()
        header_row.addWidget(SectionHeader("Dashboard", "Live system overview and one-click optimization"))
        header_row.addStretch()
        self.optimize_btn = GlowButton("⚡  OPTIMIZE PC")
        self.optimize_btn.setFixedWidth(220)
        self.optimize_btn.clicked.connect(self._run_optimize)
        header_row.addWidget(self.optimize_btn, alignment=Qt.AlignTop)
        self.content_layout.addLayout(header_row)

        # --- Optimize progress banner (hidden until running) --------------------
        self.progress_banner = QFrame()
        self.progress_banner.setProperty("cardSecondary", "true")
        self.progress_banner.setVisible(False)
        pb_layout = QVBoxLayout(self.progress_banner)
        self.progress_label = QLabel("Preparing…")
        self.progress_label.setProperty("role", "caption")
        self.progress_bar = QProgressBar()
        pb_layout.addWidget(self.progress_label)
        pb_layout.addWidget(self.progress_bar)
        self.content_layout.addWidget(self.progress_banner)

        # --- Live monitor cards ---------------------------------------------------
        grid = QGridLayout()
        grid.setSpacing(14)
        self.cpu_card = StatCard("CPU", "🧠")
        self.gpu_card = StatCard("GPU", "🎮")
        self.ram_card = StatCard("RAM", "💾")
        self.storage_card = StatCard("Storage", "🗄")
        grid.addWidget(self.cpu_card, 0, 0)
        grid.addWidget(self.gpu_card, 0, 1)
        grid.addWidget(self.ram_card, 0, 2)
        grid.addWidget(self.storage_card, 0, 3)
        self.content_layout.addLayout(grid)

        # --- Performance graphs -----------------------------------------------
        graph_card = QFrame()
        graph_card.setProperty("card", "true")
        graph_layout = QVBoxLayout(graph_card)
        graph_layout.setContentsMargins(18, 16, 18, 16)
        graph_title = QLabel("Performance Graph")
        graph_title.setProperty("role", "h2")
        graph_layout.addWidget(graph_title)

        graphs_row = QHBoxLayout()
        self.cpu_graph = LiveGraph(color=Colors.ACCENT)
        self.gpu_graph = LiveGraph(color="#FF6B6B")
        self.ram_graph = LiveGraph(color="#FFB800")
        self.net_graph = LiveGraph(color=Colors.SUCCESS)
        for label_text, graph in (("CPU", self.cpu_graph), ("GPU", self.gpu_graph),
                                   ("RAM", self.ram_graph), ("Net", self.net_graph)):
            col = QVBoxLayout()
            lbl = QLabel(label_text)
            lbl.setProperty("role", "caption")
            col.addWidget(lbl)
            col.addWidget(graph)
            graphs_row.addLayout(col)
        graph_layout.addLayout(graphs_row)
        self.content_layout.addWidget(graph_card)

        # --- Frontier Score ------------------------------------------------------
        score_card = QFrame()
        score_card.setProperty("card", "true")
        score_layout = QHBoxLayout(score_card)
        score_layout.setContentsMargins(20, 18, 20, 18)
        score_title_col = QVBoxLayout()
        st = QLabel("FRONTIER SCORE")
        st.setProperty("role", "h2")
        score_title_col.addWidget(st)
        cap = QLabel("Composite readout of headroom + applied optimizations")
        cap.setProperty("role", "caption")
        score_title_col.addWidget(cap)
        score_layout.addLayout(score_title_col)
        score_layout.addStretch()

        self.score_labels = {}
        for key, label in (("gaming", "Gaming"), ("latency", "Latency"), ("optimization", "Optimization")):
            col = QVBoxLayout()
            val = QLabel("—")
            val.setProperty("role", "stat")
            val.setStyleSheet(f"color: {Colors.ACCENT};")
            val.setAlignment(Qt.AlignCenter)
            cap2 = QLabel(label)
            cap2.setProperty("role", "caption")
            cap2.setAlignment(Qt.AlignCenter)
            col.addWidget(val)
            col.addWidget(cap2)
            score_layout.addLayout(col)
            self.score_labels[key] = val

        self.content_layout.addWidget(score_card)
        self.content_layout.addStretch()

        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh_live_stats)
        self._timer.start(1000)
        self.refresh_live_stats()

        self._worker: OptimizeWorker | None = None

    # -----------------------------------------------------------------------
    def refresh_live_stats(self):
        cpu = system_info.get_cpu_info()
        gpus = system_info.get_gpu_info()
        ram = system_info.get_ram_info()
        storage = system_info.get_storage_info()
        up_kbps, down_kbps = system_info.get_network_throughput_kbps()

        self.cpu_card.set_primary(f"{cpu.usage_percent:.0f}%", cpu.name)
        self.cpu_card.set_row("clock", f"Clock: {cpu.clock_mhz:.0f} MHz")
        self.cpu_card.set_row("cores", f"Cores: {cpu.core_count}  Threads: {cpu.thread_count}")
        self.cpu_card.set_row("temp", f"Temp: {cpu.temperature_c:.0f}°C" if cpu.temperature_c else "Temp: N/A")
        self.cpu_graph.push(cpu.usage_percent)

        gpu = gpus[0] if gpus else None
        if gpu:
            self.gpu_card.set_primary(f"{gpu.usage_percent:.0f}%", gpu.name)
            self.gpu_card.set_row("vram", f"VRAM: {gpu.vram_used_mb:.0f} / {gpu.vram_total_mb:.0f} MB")
            self.gpu_card.set_row("temp", f"Temp: {gpu.temperature_c:.0f}°C" if gpu.temperature_c else "Temp: N/A")
            self.gpu_card.set_row("driver", f"Driver: {gpu.driver_version}")
            self.gpu_graph.push(gpu.usage_percent)

        self.ram_card.set_primary(f"{ram.percent:.0f}%", f"{ram.used_gb} / {ram.total_gb} GB used")
        self.ram_card.set_row("avail", f"Available: {ram.available_gb} GB")
        self.ram_graph.push(ram.percent)

        if storage.drives:
            top = storage.drives[0]
            self.storage_card.set_primary(f"{top['percent']:.0f}%", f"{top['letter']} — {top['used_gb']}/{top['total_gb']} GB")
            for d in storage.drives[1:4]:
                self.storage_card.set_row(d["letter"], f"{d['letter']} {d['used_gb']}/{d['total_gb']} GB ({d['percent']}%)")

        self.net_graph.push(min(100.0, (up_kbps + down_kbps) / 50))

        applied = sum(1 for t in tweak_engine.ALL_TWEAKS if t.is_enabled())
        score = system_info.compute_frontier_score(cpu, ram, applied, len(tweak_engine.ALL_TWEAKS))
        for key, val in score.items():
            self.score_labels[key].setText(f"{val}%")
        if self.main_window:
            self.main_window.update_sidebar_score(score)

    # -----------------------------------------------------------------------
    def _run_optimize(self):
        if self._worker and self._worker.isRunning():
            return
        self.optimize_btn.setEnabled(False)
        self.optimize_btn.setText("Optimizing…")
        self.progress_banner.setVisible(True)
        self.progress_bar.setRange(0, len(tweak_engine.ALL_TWEAKS))
        self.progress_label.setText("Creating Backup…")

        self._worker = OptimizeWorker()
        self._worker.progress.connect(self._on_progress)
        self._worker.finished_ok.connect(self._on_finished)
        self._worker.start()

    def _on_progress(self, label: str, i: int, total: int):
        self.progress_bar.setValue(i)
        self.progress_label.setText(f"Applying: {label}  ({i}/{total})")

    def _on_finished(self, success: int, total: int):
        self.optimize_btn.setEnabled(True)
        self.optimize_btn.setText("⚡  OPTIMIZE PC")
        self.progress_label.setText(f"Complete — {success}/{total} tweaks applied.")
        if self.main_window:
            self.main_window.show_toast(f"Optimization complete: {success}/{total} tweaks applied.", "success")
        QTimer.singleShot(2500, lambda: self.progress_banner.setVisible(False))
