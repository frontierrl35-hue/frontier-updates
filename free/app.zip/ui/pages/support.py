"""
FRONTIER PREMIUM - Support Page
Discord support card, activity log viewer, HTML report export, update
checker and theme settings (red intensity / animations / compact mode).
"""
import webbrowser

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QFrame, QLabel, QPushButton,
                                QListWidget, QListWidgetItem, QSlider, QFileDialog)

from core import database, report, updater
from core.config import config
from ui.pages.base_page import BasePage
from ui.widgets import SectionHeader, ToggleSwitch, GlowButton

DISCORD_URL = "https://discord.gg/sG9jVNJsj"


class SupportPage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.content_layout.addWidget(SectionHeader("Support", "Get help, review activity, and tune app settings"))

        # --- Discord card ---------------------------------------------------------
        discord_card = QFrame()
        discord_card.setProperty("card", "true")
        d_layout = QVBoxLayout(discord_card)
        d_layout.setContentsMargins(24, 22, 24, 22)
        d_layout.setSpacing(6)
        title = QLabel("FRONTIER SUPPORT")
        title.setProperty("role", "h1")
        d_layout.addWidget(title)
        sub = QLabel("Need help? Join our Discord community for tweaks, troubleshooting and updates.")
        sub.setProperty("role", "caption")
        d_layout.addWidget(sub)
        open_btn = GlowButton("OPEN DISCORD")
        open_btn.setFixedWidth(200)
        open_btn.clicked.connect(lambda: webbrowser.open(DISCORD_URL))
        d_layout.addWidget(open_btn)
        self.content_layout.addWidget(discord_card)

        # --- Update system -----------------------------------------------------------
        update_card = QFrame()
        update_card.setProperty("card", "true")
        u_layout = QHBoxLayout(update_card)
        u_layout.setContentsMargins(18, 16, 18, 16)
        u_text = QVBoxLayout()
        u_title = QLabel("Version & Updates")
        u_title.setProperty("role", "h2")
        u_text.addWidget(u_title)
        self.version_label = QLabel(f"Current version: {report.APP_VERSION}")
        self.version_label.setProperty("role", "caption")
        u_text.addWidget(self.version_label)
        u_layout.addLayout(u_text, stretch=1)
        check_btn = QPushButton("Check for Updates")
        check_btn.setProperty("ghost", "true")
        check_btn.setCursor(Qt.PointingHandCursor)
        check_btn.clicked.connect(self._check_updates)
        u_layout.addWidget(check_btn)
        self.install_btn = QPushButton("Install Update")
        self.install_btn.setProperty("primary", "true")
        self.install_btn.setCursor(Qt.PointingHandCursor)
        self.install_btn.clicked.connect(self._install_update)
        self.install_btn.hide()
        u_layout.addWidget(self.install_btn)
        self.content_layout.addWidget(update_card)

        # --- Theme settings ------------------------------------------------------------
        theme_card = QFrame()
        theme_card.setProperty("card", "true")
        t_layout = QVBoxLayout(theme_card)
        t_layout.setContentsMargins(18, 16, 18, 16)
        t_title = QLabel("Theme Settings")
        t_title.setProperty("role", "h2")
        t_layout.addWidget(t_title)

        intensity_row = QHBoxLayout()
        intensity_row.addWidget(QLabel("Red Intensity"))
        self.intensity_slider = QSlider(Qt.Horizontal)
        self.intensity_slider.setRange(50, 150)
        self.intensity_slider.setValue(int(config.get("theme", "red_intensity", default=1.0) * 100))
        self.intensity_slider.valueChanged.connect(self._on_intensity_changed)
        intensity_row.addWidget(self.intensity_slider)
        t_layout.addLayout(intensity_row)

        anim_row = QHBoxLayout()
        anim_row.addWidget(QLabel("Animations"))
        anim_row.addStretch()
        self.anim_switch = ToggleSwitch(checked=config.get("theme", "animations_enabled", default=True))
        self.anim_switch.toggled.connect(lambda v: config.set("theme", "animations_enabled", v))
        anim_row.addWidget(self.anim_switch)
        t_layout.addLayout(anim_row)

        compact_row = QHBoxLayout()
        compact_row.addWidget(QLabel("Compact Mode"))
        compact_row.addStretch()
        self.compact_switch = ToggleSwitch(checked=config.get("theme", "compact_mode", default=False))
        self.compact_switch.toggled.connect(lambda v: config.set("theme", "compact_mode", v))
        compact_row.addWidget(self.compact_switch)
        t_layout.addLayout(compact_row)

        self.content_layout.addWidget(theme_card)

        # --- Logs & Export -------------------------------------------------------------
        logs_card = QFrame()
        logs_card.setProperty("card", "true")
        l_layout = QVBoxLayout(logs_card)
        l_layout.setContentsMargins(18, 16, 18, 16)
        l_header = QHBoxLayout()
        l_title = QLabel("Activity Logs")
        l_title.setProperty("role", "h2")
        l_header.addWidget(l_title)
        l_header.addStretch()
        export_btn = QPushButton("Export Report")
        export_btn.setProperty("primary", "true")
        export_btn.setCursor(Qt.PointingHandCursor)
        export_btn.clicked.connect(self._export_report)
        l_header.addWidget(export_btn)
        l_layout.addLayout(l_header)

        self.log_list = QListWidget()
        self.log_list.setFixedHeight(220)
        l_layout.addWidget(self.log_list)
        self.content_layout.addWidget(logs_card)
        self.content_layout.addStretch()

        self._refresh_logs()

    def on_shown(self):
        super().on_shown()
        self._refresh_logs()

    def _refresh_logs(self):
        self.log_list.clear()
        for entry in database.recent_logs(limit=60):
            import datetime
            ts = datetime.datetime.fromtimestamp(entry["ts"]).strftime("%H:%M")
            icon = {"success": "✓", "error": "✕", "warning": "!", "info": "•"}.get(entry["level"], "•")
            item = QListWidgetItem(f"{ts}  {icon}  [{entry['category']}] {entry['message']}")
            self.log_list.addItem(item)

    def _on_intensity_changed(self, value: int):
        config.set("theme", "red_intensity", value / 100)

    def _check_updates(self):
        info = report.check_for_update()
        self._last_update_info = info
        if info["error"]:
            self.version_label.setText(f"Current version: {report.APP_VERSION} — couldn't check: {info['error']}")
            self.install_btn.hide()
            if self.main_window:
                self.main_window.show_toast(f"Update check failed: {info['error']}", "warning")
        elif info["update_available"]:
            changelog = f" — {info['changelog']}" if info["changelog"] else ""
            self.version_label.setText(
                f"Current: {report.APP_VERSION} — Update available: {info['latest_version']}{changelog}")
            self.install_btn.show()
            if self.main_window:
                self.main_window.show_toast(f"Update {info['latest_version']} available.", "warning")
        else:
            self.version_label.setText(f"Current version: {report.APP_VERSION} (up to date)")
            self.install_btn.hide()
            if self.main_window:
                self.main_window.show_toast("You're on the latest version.", "success")

    def _install_update(self):
        info = getattr(self, "_last_update_info", None)
        if not info or not info.get("download_url"):
            if self.main_window:
                self.main_window.show_toast("No update package available to install.", "warning")
            return
        self.install_btn.setEnabled(False)
        self.install_btn.setText("Installing...")
        if self.main_window:
            self.main_window.show_toast("Downloading and installing update...", "warning")
        ok, message = updater.apply_update(info["download_url"])
        self.install_btn.setEnabled(True)
        self.install_btn.setText("Install Update")
        if ok:
            self.install_btn.hide()
            self.version_label.setText(f"Updated to {info['latest_version']} — restart Frontier to finish")
            if self.main_window:
                self.main_window.show_toast(message, "success")
        else:
            if self.main_window:
                self.main_window.show_toast(message, "error")

    def _export_report(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Frontier Report", "Frontier_Report.html",
                                               "HTML Files (*.html)")
        if not path:
            return
        out = report.generate_html_report(path)
        if self.main_window:
            self.main_window.show_toast(f"Report exported to {out.name}", "success")
        self._refresh_logs()
