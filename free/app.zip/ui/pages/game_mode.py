"""
FRONTIER PREMIUM - Frontier Game Mode
Toggle to enable automatic detection + priority boosting for known games,
with a live "currently running" list.
"""
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QFrame, QLabel

from core import game_mode
from core.config import config
from ui.pages.base_page import BasePage
from ui.widgets import SectionHeader, ToggleSwitch

GAME_ICONS = {
    "Fortnite": "🎯", "Rocket League": "🚗", "VALORANT": "🎯",
    "Counter-Strike 2": "🔫", "GTA V": "🏙", "Minecraft": "⛏", "Minecraft (Java)": "⛏",
}


class GameModePage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.content_layout.addWidget(SectionHeader(
            "Frontier Game Mode", "Automatic detection and performance boosting for supported games"))

        toggle_card = QFrame()
        toggle_card.setProperty("card", "true")
        toggle_layout = QHBoxLayout(toggle_card)
        toggle_layout.setContentsMargins(18, 16, 18, 16)
        text_col = QVBoxLayout()
        title = QLabel("Frontier Game Mode")
        title.setProperty("role", "h2")
        text_col.addWidget(title)
        desc = QLabel("When a supported game launches: boosts process priority, "
                       "trims background apps, and applies the gaming performance profile.")
        desc.setProperty("role", "caption")
        desc.setWordWrap(True)
        text_col.addWidget(desc)
        toggle_layout.addLayout(text_col, stretch=1)

        self.master_switch = ToggleSwitch(checked=config.get("game_mode", "enabled", default=False))
        self.master_switch.toggled.connect(self._on_master_toggle)
        toggle_layout.addWidget(self.master_switch)
        self.content_layout.addWidget(toggle_card)

        # --- Watched games list --------------------------------------------------
        list_card = QFrame()
        list_card.setProperty("card", "true")
        self.list_layout = QVBoxLayout(list_card)
        self.list_layout.setContentsMargins(18, 16, 18, 16)
        lbl = QLabel("Supported Games")
        lbl.setProperty("role", "h2")
        self.list_layout.addWidget(lbl)
        self.status_rows: dict[str, QLabel] = {}
        watched = config.get("game_mode", "watched_games", default=list(game_mode.KNOWN_GAMES))
        seen_names = set()
        for exe in watched:
            name = game_mode.KNOWN_GAMES.get(exe, exe)
            if name in seen_names:
                continue
            seen_names.add(name)
            row = QHBoxLayout()
            icon = QLabel(GAME_ICONS.get(name, "🎮"))
            row.addWidget(icon)
            row.addWidget(QLabel(name))
            row.addStretch()
            status = QLabel("Not running")
            status.setProperty("role", "caption")
            row.addWidget(status)
            self.list_layout.addLayout(row)
            self.status_rows[name] = status
        self.content_layout.addWidget(list_card)
        self.content_layout.addStretch()

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._scan)
        self._timer.start(3000)
        self._scan()

    def _on_master_toggle(self, checked: bool):
        game_mode.set_enabled(checked)
        if self.main_window:
            self.main_window.show_toast(
                "Frontier Game Mode enabled." if checked else "Frontier Game Mode disabled.",
                "success",
            )

    def _scan(self):
        running = game_mode.scan_for_running_games()
        running_names = {game_mode.KNOWN_GAMES.get(exe, exe) for exe, _, _ in running}
        for name, lbl in self.status_rows.items():
            if name in running_names:
                lbl.setText("● Running — Boosted" if self.master_switch.isChecked() else "● Running")
                lbl.setStyleSheet("color: #00FF88; font-size: 12px; font-weight: 600;")
            else:
                lbl.setText("Not running")
                lbl.setStyleSheet("color: #A0A0A0; font-size: 12px;")
        if self.master_switch.isChecked():
            for exe, name, pid in running:
                game_mode.boost_process(pid)
            if running:
                game_mode.trim_background_apps()
