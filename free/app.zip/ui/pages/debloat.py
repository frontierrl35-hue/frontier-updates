"""
FRONTIER PREMIUM - Debloat Center
Grid of built-in Microsoft app cards with individual toggles plus bulk
Remove Selected / Remove All / Restore actions.
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QGridLayout, QFrame, QLabel, QPushButton

from core.debloat_engine import APPS
from ui.pages.base_page import BasePage
from ui.widgets import TweakCard, SectionHeader


class DebloatPage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.cards: dict[str, TweakCard] = {}

        header_row = QHBoxLayout()
        header_row.addWidget(SectionHeader("Debloat Center", "Remove pre-installed Microsoft Store apps you don't use"))
        header_row.addStretch()
        self.content_layout.addLayout(header_row)

        actions_row = QHBoxLayout()
        remove_sel_btn = QPushButton("Remove Selected")
        remove_sel_btn.setProperty("primary", "true")
        remove_sel_btn.clicked.connect(self._remove_selected)
        remove_all_btn = QPushButton("Remove All Bloat")
        remove_all_btn.setProperty("danger", "true")
        remove_all_btn.clicked.connect(self._remove_all)
        restore_btn = QPushButton("Restore Apps")
        restore_btn.setProperty("ghost", "true")
        restore_btn.clicked.connect(self._restore_all)
        for b in (remove_sel_btn, remove_all_btn, restore_btn):
            b.setCursor(Qt.PointingHandCursor)
            actions_row.addWidget(b)
        actions_row.addStretch()
        self.content_layout.addLayout(actions_row)

        grid_frame = QFrame()
        grid = QGridLayout(grid_frame)
        grid.setSpacing(12)
        for i, app in enumerate(APPS):
            card = TweakCard(app.label, f"Package family: {app.package_family}", checked=app.is_removed())
            card.toggled.connect(lambda checked, a=app: self._on_toggle(a, checked))
            grid.addWidget(card, i // 2, i % 2)
            self.cards[app.id] = card
        self.content_layout.addWidget(grid_frame)
        self.content_layout.addStretch()

    def _on_toggle(self, app, checked: bool):
        ok, msg = app.remove() if checked else app.restore()
        if self.main_window:
            verb = "Removed" if checked else "Restored"
            self.main_window.show_toast(f"{verb}: {app.label}" if ok else f"Failed: {app.label}",
                                         "success" if ok else "error")

    def _remove_selected(self):
        selected = [aid for aid, card in self.cards.items() if card.switch.isChecked()]
        if not selected:
            if self.main_window:
                self.main_window.show_toast("No apps selected.", "warning")
            return
        from core.debloat_engine import remove_selected
        remove_selected(selected)
        if self.main_window:
            self.main_window.show_toast(f"Removed {len(selected)} selected app(s).", "success")

    def _remove_all(self):
        from core.debloat_engine import remove_all
        remove_all()
        for card in self.cards.values():
            card.switch.setChecked(True)
        if self.main_window:
            self.main_window.show_toast("Removed all bloatware apps.", "success")

    def _restore_all(self):
        from core.debloat_engine import restore_all
        restore_all()
        for card in self.cards.values():
            card.switch.setChecked(False)
        if self.main_window:
            self.main_window.show_toast("Restored all apps.", "success")
