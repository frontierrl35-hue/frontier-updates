"""
FRONTIER PREMIUM - Network Page
TCP/UDP tweak toggles, a "Network Priority Tool" (QoS by executable name),
and a bufferbloat idle-vs-load latency test.
"""
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QHBoxLayout, QVBoxLayout, QFrame, QLabel, QLineEdit,
                                QPushButton)

from core.tweak_engine import TweakCategory
from core import network_tools
from ui.pages.base_page import BasePage
from ui.pages.tweak_page import TweakSection
from ui.widgets import SectionHeader


class BufferbloatWorker(QThread):
    result = Signal(dict)

    def run(self):
        self.result.emit(network_tools.bufferbloat_test())


class NetworkPage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.content_layout.addWidget(SectionHeader(
            "Network Optimizer", "TCP/UDP tuning, per-game QoS priority and latency testing"))

        self.content_layout.addWidget(TweakSection(TweakCategory.NETWORK, "Optimization", main_window))

        # --- Priority tool -------------------------------------------------------
        priority_card = QFrame()
        priority_card.setProperty("card", "true")
        p_layout = QVBoxLayout(priority_card)
        p_layout.setContentsMargins(18, 16, 18, 16)
        title = QLabel("Network Priority Tool")
        title.setProperty("role", "h2")
        p_layout.addWidget(title)
        cap = QLabel("Enter an executable name (e.g. Game.exe) to create a high-priority QoS policy.")
        cap.setProperty("role", "caption")
        p_layout.addWidget(cap)

        row = QHBoxLayout()
        self.exe_input = QLineEdit()
        self.exe_input.setPlaceholderText("Game.exe")
        row.addWidget(self.exe_input, stretch=1)
        create_btn = QPushButton("Create Priority")
        create_btn.setProperty("primary", "true")
        create_btn.setCursor(Qt.PointingHandCursor)
        create_btn.clicked.connect(self._create_priority)
        row.addWidget(create_btn)
        p_layout.addLayout(row)

        self.priority_status = QLabel("")
        self.priority_status.setProperty("role", "caption")
        p_layout.addWidget(self.priority_status)
        self.content_layout.addWidget(priority_card)

        # --- Bufferbloat test ------------------------------------------------------
        bb_card = QFrame()
        bb_card.setProperty("card", "true")
        bb_layout = QVBoxLayout(bb_card)
        bb_layout.setContentsMargins(18, 16, 18, 16)
        bb_title = QLabel("Bufferbloat Test")
        bb_title.setProperty("role", "h2")
        bb_layout.addWidget(bb_title)

        results_row = QHBoxLayout()
        self.idle_label = self._stat_block("Idle", "—")
        self.load_label = self._stat_block("Under Load", "—")
        results_row.addLayout(self.idle_label[0])
        results_row.addLayout(self.load_label[0])
        results_row.addStretch()
        bb_layout.addLayout(results_row)

        run_btn = QPushButton("Run Test")
        run_btn.setProperty("ghost", "true")
        run_btn.setCursor(Qt.PointingHandCursor)
        run_btn.clicked.connect(self._run_bufferbloat)
        bb_layout.addWidget(run_btn, alignment=Qt.AlignLeft)
        self.content_layout.addWidget(bb_card)
        self.content_layout.addStretch()

        self._bb_worker: BufferbloatWorker | None = None

    @staticmethod
    def _stat_block(title: str, value: str):
        layout = QVBoxLayout()
        val_lbl = QLabel(value)
        val_lbl.setProperty("role", "stat")
        cap_lbl = QLabel(title)
        cap_lbl.setProperty("role", "caption")
        layout.addWidget(val_lbl)
        layout.addWidget(cap_lbl)
        return layout, val_lbl

    def _create_priority(self):
        exe = self.exe_input.text().strip()
        if not exe:
            self.priority_status.setText("Enter an executable name first.")
            return
        path = network_tools.find_executable(exe)
        if not path:
            self.priority_status.setText(f"Could not locate '{exe}'. Make sure it's running or installed.")
            return
        ok, msg = network_tools.create_qos_policy(exe, path)
        self.priority_status.setText(msg)
        if self.main_window:
            self.main_window.show_toast(f"QoS priority created for {exe}" if ok else f"Failed for {exe}",
                                         "success" if ok else "error")

    def _run_bufferbloat(self):
        if self._bb_worker and self._bb_worker.isRunning():
            return
        self._bb_worker = BufferbloatWorker()
        self._bb_worker.result.connect(self._on_bufferbloat_result)
        self._bb_worker.start()

    def _on_bufferbloat_result(self, result: dict):
        self.idle_label[1].setText(f"{result['idle_ms']}ms")
        self.load_label[1].setText(f"{result['loaded_ms']}ms")
