"""
FRONTIER PREMIUM - Generic Tweak Category Page
Renders a list of TweakCard widgets for one or more TweakCategory groups.
Reused by the General, Network and Advanced pages, and embedded per-section
inside the Hardware page (CPU / GPU / RAM / Storage / Input).
"""
from PySide6.QtWidgets import QVBoxLayout, QLabel, QFrame

from core.tweak_engine import Tweak, TweakCategory, TWEAKS_BY_CATEGORY
from ui.pages.base_page import BasePage
from ui.widgets import TweakCard, SectionHeader, ToastNotification


class TweakSection(QFrame):
    """A titled block of TweakCards for a single category — used both as a
    standalone page body and embedded (e.g. Hardware page stacks several)."""

    def __init__(self, category: TweakCategory, title: str | None = None, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        if title:
            lbl = QLabel(title)
            lbl.setProperty("role", "h2")
            layout.addWidget(lbl)

        for tweak in TWEAKS_BY_CATEGORY.get(category, []):
            card = TweakCard(tweak.label, tweak.description, checked=tweak.is_enabled(), risk=tweak.risk)
            card.toggled.connect(lambda checked, t=tweak: self._on_toggle(t, checked))
            layout.addWidget(card)

    def _on_toggle(self, tweak: Tweak, checked: bool):
        if checked:
            ok, msg = tweak.apply()
        else:
            ok, msg = tweak.revert()
        if self.main_window:
            level = "success" if ok else "error"
            verb = "Applied" if checked else "Reverted"
            self.main_window.show_toast(f"{verb}: {tweak.label}" if ok else f"Failed: {tweak.label} — {msg}", level)


class TweakCategoryPage(BasePage):
    """A full page (used by sidebar items General / Network / Advanced)."""

    def __init__(self, category: TweakCategory, title: str, subtitle: str, main_window=None, parent=None):
        super().__init__(parent)
        self.content_layout.addWidget(SectionHeader(title, subtitle))
        section = TweakSection(category, main_window=main_window)
        self.content_layout.addWidget(section)
        self.content_layout.addStretch()
