"""
FRONTIER PREMIUM - Backups & Fixes
One-click System Restore point creation plus a grid of common repair tools.
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QGridLayout, QFrame, QLabel, QPushButton

from core.backup_engine import FIX_TOOLS, create_restore_point, run_fix
from ui.pages.base_page import BasePage
from ui.widgets import SectionHeader, GlowButton


class BackupsPage(BasePage):
    def __init__(self, main_window=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.content_layout.addWidget(SectionHeader(
            "Backups & Fixes", "Create restore points before tweaking, and repair common services"))

        restore_card = QFrame()
        restore_card.setProperty("card", "true")
        r_layout = QHBoxLayout(restore_card)
        r_layout.setContentsMargins(18, 16, 18, 16)
        text_col = QVBoxLayout()
        title = QLabel("System Restore Point")
        title.setProperty("role", "h2")
        text_col.addWidget(title)
        desc = QLabel("Creates a Windows restore point labeled 'Before Frontier Free' so any "
                       "change can be rolled back from Windows Recovery.")
        desc.setProperty("role", "caption")
        desc.setWordWrap(True)
        text_col.addWidget(desc)
        r_layout.addLayout(text_col, stretch=1)

        create_btn = GlowButton("Create Restore Point")
        create_btn.setFixedWidth(220)
        create_btn.clicked.connect(self._create_restore_point)
        r_layout.addWidget(create_btn)
        self.content_layout.addWidget(restore_card)

        fixes_lbl = QLabel("Fix Tools")
        fixes_lbl.setProperty("role", "h2")
        self.content_layout.addWidget(fixes_lbl)

        grid_frame = QFrame()
        grid = QGridLayout(grid_frame)
        grid.setSpacing(12)
        for i, (fix_id, (label, desc, _script)) in enumerate(FIX_TOOLS.items()):
            card = self._fix_card(fix_id, label, desc)
            grid.addWidget(card, i // 2, i % 2)
        self.content_layout.addWidget(grid_frame)
        self.content_layout.addStretch()

    def _fix_card(self, fix_id: str, label: str, desc: str) -> QFrame:
        card = QFrame()
        card.setProperty("card", "true")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        title = QLabel(label)
        title.setProperty("role", "h2")
        layout.addWidget(title)
        d = QLabel(desc)
        d.setProperty("role", "caption")
        d.setWordWrap(True)
        layout.addWidget(d)
        run_btn = QPushButton("Run Fix")
        run_btn.setProperty("ghost", "true")
        run_btn.setCursor(Qt.PointingHandCursor)
        run_btn.clicked.connect(lambda: self._run_fix(fix_id, label))
        layout.addWidget(run_btn, alignment=Qt.AlignLeft)
        return card

    def _create_restore_point(self):
        ok, msg = create_restore_point()
        if self.main_window:
            self.main_window.show_toast(
                "Restore point created." if ok else f"Failed to create restore point: {msg}",
                "success" if ok else "error",
            )

    def _run_fix(self, fix_id: str, label: str):
        ok, msg = run_fix(fix_id)
        if self.main_window:
            self.main_window.show_toast(f"{label} completed." if ok else f"{label} failed: {msg}",
                                         "success" if ok else "error")
