"""
FRONTIER PREMIUM - Custom Widget Library
ToggleSwitch, StatCard, TweakCard, LiveGraph, ToastNotification, GlowButton.
All widgets are QWidget/QFrame subclasses styled through core.theme's QSS
plus a handful of hand-drawn QPainter widgets (toggle switch, live graph)
for the premium feel that plain stylesheets can't deliver.
"""
from __future__ import annotations

from collections import deque

from PySide6.QtCore import (Qt, QPropertyAnimation, QEasingCurve, Property,
                             Signal, QRectF, QPointF, QTimer)
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QLinearGradient, QFont
from PySide6.QtWidgets import (QWidget, QFrame, QLabel, QHBoxLayout, QVBoxLayout,
                                QPushButton, QGraphicsOpacityEffect, QSizePolicy)

from core.theme import Colors


# ---------------------------------------------------------------------------
# ToggleSwitch — animated iOS-style switch used throughout the tweak pages
# ---------------------------------------------------------------------------
class ToggleSwitch(QWidget):
    toggled = Signal(bool)

    def __init__(self, checked: bool = False, parent=None):
        super().__init__(parent)
        self.setFixedSize(46, 26)
        self.setCursor(Qt.PointingHandCursor)
        self._checked = checked
        self._pos = 1.0 if checked else 0.0
        self._anim = QPropertyAnimation(self, b"pos_value", self)
        self._anim.setDuration(160)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)

    def _get_pos(self):
        return self._pos

    def _set_pos(self, value):
        self._pos = value
        self.update()

    pos_value = Property(float, _get_pos, _set_pos)

    def isChecked(self) -> bool:
        return self._checked

    def setChecked(self, checked: bool, animate: bool = True):
        if checked == self._checked:
            return
        self._checked = checked
        if animate:
            self._anim.stop()
            self._anim.setStartValue(self._pos)
            self._anim.setEndValue(1.0 if checked else 0.0)
            self._anim.start()
        else:
            self._pos = 1.0 if checked else 0.0
            self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.setChecked(not self._checked)
            self.toggled.emit(self._checked)
        super().mousePressEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        track_rect = QRectF(0, 4, self.width(), self.height() - 8)
        off_color = QColor(Colors.SECONDARY)
        on_color = QColor(Colors.ACCENT)
        r = self._pos
        track_color = QColor(
            int(off_color.red() + (on_color.red() - off_color.red()) * r),
            int(off_color.green() + (on_color.green() - off_color.green()) * r),
            int(off_color.blue() + (on_color.blue() - off_color.blue()) * r),
        )
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(track_color))
        painter.drawRoundedRect(track_rect, track_rect.height() / 2, track_rect.height() / 2)

        knob_d = self.height() - 4
        knob_x = 2 + r * (self.width() - knob_d - 4)
        painter.setBrush(QBrush(QColor(Colors.TEXT)))
        painter.drawEllipse(QRectF(knob_x, 2, knob_d, knob_d))


# ---------------------------------------------------------------------------
# StatCard — dashboard hardware readout card (title, big value, sub-rows)
# ---------------------------------------------------------------------------
class StatCard(QFrame):
    def __init__(self, title: str, icon_text: str = "", parent=None):
        super().__init__(parent)
        self.setProperty("card", "true")
        self.setMinimumHeight(150)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(6)

        header = QHBoxLayout()
        icon_lbl = QLabel(icon_text)
        icon_lbl.setStyleSheet(f"font-size: 18px;")
        title_lbl = QLabel(title)
        title_lbl.setProperty("role", "h2")
        header.addWidget(icon_lbl)
        header.addWidget(title_lbl)
        header.addStretch()
        layout.addLayout(header)

        self.primary_value = QLabel("—")
        self.primary_value.setProperty("role", "stat")
        layout.addWidget(self.primary_value)

        self.sub_label = QLabel("")
        self.sub_label.setProperty("role", "caption")
        self.sub_label.setWordWrap(True)
        layout.addWidget(self.sub_label)

        self.rows_layout = QVBoxLayout()
        self.rows_layout.setSpacing(3)
        layout.addLayout(self.rows_layout)
        layout.addStretch()
        self._row_labels: dict[str, QLabel] = {}

    def set_primary(self, value: str, sub: str = ""):
        self.primary_value.setText(value)
        self.sub_label.setText(sub)

    def set_row(self, key: str, text: str):
        if key not in self._row_labels:
            lbl = QLabel()
            lbl.setProperty("role", "caption")
            lbl.setStyleSheet(f"color: {Colors.TEXT_SECONDARY}; font-size: 11px;")
            self.rows_layout.addWidget(lbl)
            self._row_labels[key] = lbl
        self._row_labels[key].setText(text)


# ---------------------------------------------------------------------------
# TweakCard — a card with title/description + ToggleSwitch, used on every
# optimization page
# ---------------------------------------------------------------------------
class TweakCard(QFrame):
    toggled = Signal(bool)

    RISK_COLORS = {"safe": Colors.SUCCESS, "moderate": "#FFB800", "advanced": Colors.DANGER}

    def __init__(self, title: str, description: str, checked: bool = False,
                 risk: str = "safe", parent=None):
        super().__init__(parent)
        self.setProperty("card", "true")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(12)

        text_col = QVBoxLayout()
        text_col.setSpacing(4)
        title_row = QHBoxLayout()
        title_row.setSpacing(8)
        title_lbl = QLabel(title)
        title_lbl.setProperty("role", "h2")
        title_row.addWidget(title_lbl)

        if risk != "safe":
            badge = QLabel(risk.upper())
            badge.setStyleSheet(
                f"background-color: rgba(255,255,255,0.06); color: {self.RISK_COLORS.get(risk, Colors.TEXT_SECONDARY)};"
                f"font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 4px;"
            )
            title_row.addWidget(badge)
        title_row.addStretch()
        text_col.addLayout(title_row)

        desc_lbl = QLabel(description)
        desc_lbl.setProperty("role", "caption")
        desc_lbl.setWordWrap(True)
        text_col.addWidget(desc_lbl)

        layout.addLayout(text_col, stretch=1)

        self.switch = ToggleSwitch(checked=checked)
        self.switch.toggled.connect(self.toggled.emit)
        layout.addWidget(self.switch, alignment=Qt.AlignVCenter)


# ---------------------------------------------------------------------------
# GlowButton — the big red "⚡ OPTIMIZE PC" call-to-action button
# ---------------------------------------------------------------------------
class GlowButton(QPushButton):
    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setProperty("primary", "true")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(52)
        font = QFont()
        font.setPointSize(13)
        font.setBold(True)
        self.setFont(font)


# ---------------------------------------------------------------------------
# LiveGraph — lightweight hand-painted rolling line chart (no matplotlib
# dependency needed for the always-on dashboard sparkline; matplotlib is
# used separately for the bigger performance graph panel).
# ---------------------------------------------------------------------------
class LiveGraph(QWidget):
    def __init__(self, max_points: int = 60, color: str = Colors.ACCENT, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(80)
        self._data: deque[float] = deque([0.0] * max_points, maxlen=max_points)
        self._color = QColor(color)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def push(self, value: float):
        self._data.append(max(0.0, min(100.0, value)))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        if len(self._data) < 2:
            return

        step = w / (len(self._data) - 1)
        points = [
            QPointF(i * step, h - (v / 100.0) * (h - 6) - 3)
            for i, v in enumerate(self._data)
        ]

        # Filled gradient area under the line
        gradient = QLinearGradient(0, 0, 0, h)
        fill_color = QColor(self._color)
        fill_color.setAlpha(90)
        gradient.setColorAt(0.0, fill_color)
        transparent = QColor(self._color)
        transparent.setAlpha(0)
        gradient.setColorAt(1.0, transparent)

        path_points = points + [QPointF(w, h), QPointF(0, h)]
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(gradient))
        from PySide6.QtGui import QPolygonF
        painter.drawPolygon(QPolygonF(path_points))

        pen = QPen(self._color, 2)
        painter.setPen(pen)
        for i in range(len(points) - 1):
            painter.drawLine(points[i], points[i + 1])


# ---------------------------------------------------------------------------
# ToastNotification — small fade-in/out popup used for "applied", "removed",
# "error" feedback across the whole app.
# ---------------------------------------------------------------------------
class ToastNotification(QFrame):
    LEVEL_COLORS = {"info": Colors.TEXT_SECONDARY, "success": Colors.SUCCESS,
                     "warning": "#FFB800", "error": Colors.DANGER}

    def __init__(self, message: str, level: str = "info", parent=None):
        super().__init__(parent)
        self.setProperty("cardSecondary", "true")
        self.setFixedHeight(44)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 0, 14, 0)

        dot = QLabel("●")
        dot.setStyleSheet(f"color: {self.LEVEL_COLORS.get(level, Colors.TEXT)}; font-size: 14px;")
        layout.addWidget(dot)

        lbl = QLabel(message)
        lbl.setStyleSheet("font-size: 12px;")
        layout.addWidget(lbl)
        layout.addStretch()

        self._effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._effect)
        self._effect.setOpacity(0.0)

        self._anim_in = QPropertyAnimation(self._effect, b"opacity", self)
        self._anim_in.setDuration(220)
        self._anim_in.setStartValue(0.0)
        self._anim_in.setEndValue(1.0)

        self._anim_out = QPropertyAnimation(self._effect, b"opacity", self)
        self._anim_out.setDuration(280)
        self._anim_out.setStartValue(1.0)
        self._anim_out.setEndValue(0.0)
        self._anim_out.finished.connect(self.deleteLater)

    def show_animated(self, duration_ms: int = 2800):
        self.show()
        self._anim_in.start()
        QTimer.singleShot(duration_ms, self._anim_out.start)


class SectionHeader(QWidget):
    def __init__(self, title: str, subtitle: str = "", parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        t = QLabel(title)
        t.setProperty("role", "h1")
        layout.addWidget(t)
        if subtitle:
            s = QLabel(subtitle)
            s.setProperty("role", "caption")
            layout.addWidget(s)
