"""
FRONTIER PREMIUM - Main Window
Frameless QMainWindow hosting the custom title bar, sidebar, page stack, and
a floating toast container. Handles fade/slide page transitions.
"""
from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QPoint
from PySide6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
                                QStackedWidget, QGraphicsDropShadowEffect)
from PySide6.QtGui import QColor

from core.theme import Colors, build_stylesheet
from core.tweak_engine import TweakCategory
from ui.title_bar import TitleBar
from ui.sidebar import Sidebar
from ui.widgets import ToastNotification

from ui.pages.home import HomePage
from ui.pages.tweak_page import TweakCategoryPage
from ui.pages.hardware import HardwarePage
from ui.pages.debloat import DebloatPage
from ui.pages.network import NetworkPage
from ui.pages.game_mode import GameModePage
from ui.pages.backups import BackupsPage
from ui.pages.support import SupportPage

WINDOW_DEFAULT_SIZE = (1300, 800)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Frontier Free")
        self.resize(*WINDOW_DEFAULT_SIZE)
        self.setMinimumSize(1000, 650)

        # Frameless + rounded corners + shadow ------------------------------------------
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.setAttribute(Qt.WA_TranslucentBackground)

        root = QWidget()
        root.setObjectName("RootBackground")
        root.setStyleSheet(f"#RootBackground {{ background-color: {Colors.BACKGROUND}; "
                            f"border-radius: 14px; border: 1px solid {Colors.BORDER}; }}")
        self.setCentralWidget(root)

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(48)
        shadow.setOffset(0, 8)
        shadow.setColor(QColor(0, 0, 0, 180))
        root.setGraphicsEffect(shadow)

        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.title_bar = TitleBar(self)
        outer.addWidget(self.title_bar)

        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)
        outer.addWidget(body)

        self.sidebar = Sidebar()
        self.sidebar.page_selected.connect(self.navigate_to)
        body_layout.addWidget(self.sidebar)

        # --- Page stack --------------------------------------------------------------
        self.stack = QStackedWidget()
        self.stack.setObjectName("MainContentStack")
        self.stack.setMinimumWidth(500)
        body_layout.addWidget(self.stack, stretch=1)
        self.stack.setSizePolicy(__import__('PySide6').QtWidgets.QSizePolicy.Expanding, __import__('PySide6').QtWidgets.QSizePolicy.Expanding)

        self.pages: dict[str, QWidget] = {}
        self._build_pages()
        print("[Frontier] Pages created:", list(self.pages.keys()))

        for page_id, widget in self.pages.items():
            widget.setObjectName(f"Page_{page_id}")
            self.stack.addWidget(widget)
            print("[Frontier] Added page:", page_id, type(widget).__name__)

        # Ensure the content stack is initialized and visible
        if self.stack.count() > 0:
            self.stack.setCurrentIndex(0)
            self.stack.show()
            self.stack.raise_()
            self.stack.update()

        # --- Toast overlay -------------------------------------------------------------
        self._toast_container = QWidget(root)
        self._toast_container.setFixedWidth(340)
        self._toast_layout = QVBoxLayout(self._toast_container)
        self._toast_layout.setContentsMargins(0, 0, 0, 0)
        self._toast_layout.setSpacing(8)
        self._toast_layout.addStretch()
        self._position_toast_container()

        self.navigate_to("home")

    def _build_pages(self):
        # Build every page safely. If one module fails, keep the application alive
        # and display the real error instead of leaving a blank content area.
        builders = {
            "home": lambda: HomePage(main_window=self),
            "general": lambda: TweakCategoryPage(TweakCategory.GENERAL, "General", "Core Windows behavior and UI optimization", main_window=self),
            "hardware": lambda: HardwarePage(main_window=self),
            "debloat": lambda: DebloatPage(main_window=self),
            "network": lambda: NetworkPage(main_window=self),
            "game_mode": lambda: GameModePage(main_window=self),
            "backups": lambda: BackupsPage(main_window=self),
            "support": lambda: SupportPage(main_window=self),
        }

        for page_id, builder in builders.items():
            try:
                self.pages[page_id] = builder()
            except Exception as e:
                from PySide6.QtWidgets import QLabel, QVBoxLayout
                error_page = QWidget()
                layout = QVBoxLayout(error_page)
                label = QLabel(f"Frontier Free page failed to load\n\n{page_id}\n\n{type(e).__name__}: {e}")
                label.setWordWrap(True)
                layout.addWidget(label)
                self.pages[page_id] = error_page

    def navigate_to(self, page_id: str):
        widget = self.pages.get(page_id)
        if not widget:
            print(f"[Frontier] navigate_to: no page registered for id={page_id!r}")
            return
        self.stack.setCurrentWidget(widget)
        self.stack.show()
        self.stack.update()
        if hasattr(widget, "on_shown"):
            widget.on_shown()

    def update_sidebar_score(self, score: dict):
        self.sidebar.update_score(score.get("gaming", 0), score.get("latency", 0), score.get("optimization", 0))

    def show_toast(self, message: str, level: str = "info"):
        toast = ToastNotification(message, level, parent=self._toast_container)
        self._toast_layout.insertWidget(self._toast_layout.count() - 1, toast)
        toast.show_animated()

    def _position_toast_container(self):
        margin = 20
        self._toast_container.move(
            self.width() - self._toast_container.width() - margin,
            self.title_bar.height() + margin,
        )
        self._toast_container.raise_()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_toast_container()
