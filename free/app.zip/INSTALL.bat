@echo off
setlocal
title Frontier Premium 1.0 - Installer
color 0C
cd /d "%~dp0"

echo ==========================================
echo     FRONTIER PREMIUM 1.0 INSTALLER
echo ==========================================
echo.

where python >nul 2>&1
if errorlevel 1 (
 echo Python is not installed or not in PATH.
 echo Install Python 3.12+ and enable Add Python to PATH.
 pause
 exit /b 1
)

echo Creating virtual environment...
if not exist ".venv\Scripts\python.exe" (
 python -m venv .venv
 if errorlevel 1 goto fail
)

echo Installing dependencies...
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto fail

echo.
echo Creating launcher shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Frontier Premium.lnk');$s.TargetPath='%~dp0RUN_FRONTIER.bat';$s.WorkingDirectory='%~dp0';$s.IconLocation='%SystemRoot%\System32\SHELL32.dll,44';$s.Save()"

echo.
echo ==========================================
echo INSTALL COMPLETE
echo Use RUN_FRONTIER.bat or the desktop shortcut.
echo ==========================================
pause
exit /b 0

:fail
echo.
echo INSTALL FAILED. Check the error above.
pause
exit /b 1
