@echo off
title Frontier Premium - Quick Optimize
cd /d "%~dp0"

REM ------------------------------------------------------------------
REM Self-elevate to Administrator — required for registry/service/
REM powercfg changes to actually take effect.
REM ------------------------------------------------------------------
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo   [ERROR] Frontier Premium has not been installed yet.
    echo   Run INSTALL.bat first, then try again.
    echo.
    pause
    exit /b 1
)

echo.
echo   This will apply EVERY Frontier Premium tweak directly,
echo   without opening the app. A System Restore point is
echo   created first so you can roll back if needed.
echo.
set /p CONFIRM="  Continue? (Y/N): "
if /i not "%CONFIRM%"=="Y" (
    echo   Cancelled.
    pause
    exit /b 0
)

".venv\Scripts\python.exe" -m core.cli_optimize

echo.
pause
