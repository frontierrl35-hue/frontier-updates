Place Inter (SemiBold/Regular) and JetBrains Mono .ttf/.otf files here to
have Frontier Premium embed them at startup. Both are free/open-source:

  Inter          -> https://rsms.me/inter/
  JetBrains Mono -> https://www.jetbrains.com/lp/mono/

If this folder is empty, the app falls back to Segoe UI / Consolas
automatically — no crash, just a slightly different look.
